// type AddFn = (n1: number, n2: number) => number;

interface AddFn {
    (n1: number, n2: number): number;
}

let add: AddFn;

add = (n1: number, n2: number) => n1 + n2;
    
interface Named {
    readonly name?: string;
    outputName?: string;
    greet?(phrase: string): void;
}

interface Greetable extends Named {
    greet(phrase: string): void;
}

class Person implements Greetable{
    name?: string;
    constructor(public age: number, name?: string) {
        if (name) {
            this.name = name;
        }
    }
    greet(phrase: string): void {
        if (this.name) {
            console.log(`${phrase}. I am ${this.name}`)
        } else {
            console.log('Hi');
        }
    }
}

let user: Greetable;
user = new Person(30);

// user = {
//     name: 'Jeff', 
//     age: 30,
// }

user.greet('Hello, there');