1. Intersection Types
2. Type Guards
3. Discriminated Unions
4. Type Casting
5. Function Overloads

# Intersection Types
Use the ampersand '&'. It can be used to extend a type of object with another type of object.
It also could be used to link the union types.
```
type Admin = {
    name: string;
    privileges: string[];
}

type Employee = {
    name: string;
    startDate: Date;
}

type ElevatedEmployee = Admin & Employee;

const user: ElevatedEmployee = {
    name: 'Jeff',
    privileges: ['create-database'],
    startDate: new Date()
}

type Combinable = string | number;
type Numeric = number | boolean;

type Universal = Combinable & Numeric;

const a: Universal = 2;
```

# type Guard 
It allows flexibility the union type offers, in the mean time, ensure the type for the runtime.

You can use the following three methods to be as type guard.
1. typeof
2. in
3. instanceof
```

```

# Discriminated Unions 
It is a pattern that makes type guard in union types easier.
```
interface bird {
    type: 'bird';
    flyingSpeed: number;
}

interface Horse {
    type: 'horse';
    runningSpeed: number;
}

type Animal = bird | Horse;

function moveAnimal(animal: Animal) {
    let speed: number;
    switch (animal.type) {
        case 'bird':
            speed = animal.flyingSpeed;
            console.log('Flying at speed ' + speed);
            break;
        case 'horse':
            speed = animal.runningSpeed;
            console.log('Running at speed ' + speed);
            break;
    }
}

const myBird: Animal = {type: 'bird', flyingSpeed:30}

moveAnimal(myBird)
```

# Type Casting
It is to tell TS what the type of a value will be.
```
// const userInputElement = <HTMLInputElement>document.querySelector('#user-input')!;
const userInputElement = document.querySelector('#user-input') as HTMLInputElement;

userInputElement.value = 'haha'
```

## Exclamation 
The '!' is to indicate that the expersion before it will always yield some value other than undefined.
`$ const userInputElement = document.querySelector('#user-input')!;`

If you use type casting behind the expression it will implicitly says the expression will always be evaluated to a value.
Otherwise you need to use if check.
```
const userInputElement = document.querySelector('#user-input') as HTMLInputElement

```

# index properties
It is used when you don't know the property's name in advance but do know the possible type of values.
```
interface ErrorContainer {
    [prop: string]: string;
}

const errorBag: ErrorContainer = {
    email: 'Not a valid email',
    username: 'username must start with a capital character'
}
```

# Optional Chaining
If you are not sure the fetchedUserData has a nested job object or not, you put the '?' behind the doutable property's name.
Rightnow, it's a vanilla JS feature as well.
```
const fetchedUserData = {
    name: 'Jeff',
    age: 30,
    // job: {title: 'developer'}
}

console.log(fetchedUserData.job?.title);
```

# Nullish Coalescing
If userInput is null or undefine the result will be resolved to 'Default'. It's different from false value evaluaion using '||' short-curcit.
```
const userInput = 0;

const res = userInput ?? 'Default';
```