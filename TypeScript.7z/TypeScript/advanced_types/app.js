"use strict";
var _a;
console.log("Beginning the the script!");
const user = {
    name: 'Jeff',
    privileges: ['create-database'],
    startDate: new Date()
};
const a = 2;
function add(a, b) {
    // typeof as type guard
    if (typeof a === 'string' || typeof b === 'string') {
        return a.toString() + b.toString();
    }
    return a + b;
}
let result = add('1', 2);
function printEmployeeInformation(emp) {
    console.log(emp.name);
    // in keyword as type guard
    if ('privileges' in emp) {
        console.log(emp.privileges);
    }
    if ('startDate' in emp) {
        console.log(emp.startDate);
    }
}
const employee_a = {
    name: 'Jeff',
    privileges: ['create-account']
};
printEmployeeInformation(employee_a);
class Car {
    drive() {
        console.log('Driving...');
    }
}
class Truck {
    drive() {
        console.log('Driving a truck...');
    }
    loadCargo() {
        console.log('Loading Cargo...');
    }
}
let myTruck = new Truck();
let myCar = new Car();
function driveVehicle(v) {
    // using instanceof as type guard
    v.drive();
    if (v instanceof Truck) {
        v.loadCargo();
    }
}
driveVehicle(myTruck);
driveVehicle(myCar);
function moveAnimal(animal) {
    let speed;
    switch (animal.type) {
        case 'bird':
            speed = animal.flyingSpeed;
            console.log('Flying at speed ' + speed);
            break;
        case 'horse':
            speed = animal.runningSpeed;
            console.log('Running at speed ' + speed);
            break;
    }
}
const myBird = { type: 'bird', flyingSpeed: 30 };
moveAnimal(myBird);
// Type Casting
// const userInputElement = <HTMLInputElement>document.querySelector('#user-input')!;
// const userInputElement = document.querySelector('#user-input')! as HTMLInputElement;
const userInputElement = document.querySelector('#user-input');
if (userInputElement) {
    userInputElement.value = 'xixi';
}
const errorBag = {
    email: 'Not a valid email',
    username: 'username must start with a capital character'
};
// Optional Chaining
const fetchedUserData = {
    name: 'Jeff',
    age: 30,
    // job: {title: 'developer'}
};
console.log((_a = fetchedUserData.job) === null || _a === void 0 ? void 0 : _a.title);
// Nullish Coalescing
const userInput = 0;
const res = userInput !== null && userInput !== void 0 ? userInput : 'Default';
