# What is Object-oriented Programming
You work with (real-life) Entities in your Code. It makes you easilier to reason with your code.

# Classes & Instances
__Objects__ are the things you work in code.
They are intances of Classes (= based on classes).
Class-based creation is an alternative to using object literals!

__Classes__ are the blueprints for objects (theoretical definition).
They define how objects look like, which properties and methods they have.
Classes make creation of multiple, similar objects more easier.

# Interface
Interface describes a structure of an object and a function. This only exists in TS.

## Interface vs custom type as object
Interface could only describe a object type and a function. And Interface can be contracts for the Classes to adhere.
Classes can implement multiple interfaces at the same time.

## Interface vs abstract class
Abstract class can have both concrete methods and abstract methods, while interface can only have abstract methods.

## To make sure certain object has a specific method no matter what it is
In the following example, we don't care what exactly the user is but the method it has.
```
let user: Greetable;
user = new Person('Jeff1', 30);

// user = {
//     name: 'Jeff', 
//     age: 30,
// }

user.greet('Hello, there');
```

## readonly

## Interface can extends another Interface, even multple interfaces which is not applicable for Classes

## interface to describe the structure of a function
```
interface AddFn {
    (n1: number, n2: number): number;
}

let add: AddFn;

add = (n1: number, n2: number) => n1 + n2;
```

## Optional Properties, Methods & parameters
```
interface Named {
    readonly name?: string;
    outputName?: string;
}

interface Greetable extends Named {
    greet(phrase: string): void;
}

class Person implements Greetable{
    name?: string;
    constructor(public age: number, name?: string) {
        if (name) {
            this.name = name;
        }
    }
    greet(phrase: string): void {
        console.log(`${phrase}. I am ${this.name}`)
    }
}
```

## Interfaces will not be compiled into JS