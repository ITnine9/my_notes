console.log("Beginning the the script!");
const btn = document.querySelector('button')!;

btn.addEventListener('click', () => {
    console.log('clicked! lala');
})