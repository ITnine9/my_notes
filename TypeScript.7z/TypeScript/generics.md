# Definition
The generic type is connected to other types. And it is flexible about which type the other type is.

The following types are the built-in generic type
1. Array type
2. promise type

```
const names: Array<string> = []; // string []\
// names[0].split(' ');

const promise: Promise<string> = new Promise((resolve, reject) => {
    setTimeout(() => {
        resolve('This is done!');
    }, 2000);
})

promise.then(res => {
    res.split(' ');
})
```

You can build your own generics function or class.

# generics type constraints

```
function merge<T extends object, U extends object>(objA: T, objB: U) {
    return Object.assign(objA, objB);
}
```

The following code constrains the parameter to have length property.
```
interface Lengthy {
    length: number
}

function countAndDescribe<T extends Lengthy>(element: T): [T, string] {
    let descriptionText = 'Got no value';
    if (element.length === 1) {
        descriptionText = 'Got 1 element';
    } else if (element.length > 1) {
        descriptionText = 'Got ' + element.length +' elements';
    }

    return [element, descriptionText]; 
}

console.log(countAndDescribe('hello, world'));
console.log(countAndDescribe(['apple', 'banana']));
console.log(countAndDescribe([]));
```