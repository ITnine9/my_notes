# Definition
TypeScript is a JavaScript Superset. It's built upon the JavaScript, so it is not a totally new programming language. TypeScript addes new features and advantages to JS. However, the disvantage is that the browser and node can't execute TS directly. TS is compiled to JS "workarounds" then it could be executed by the mentioned enviroments. Thus, make program TS more easier. It also helps to catch the errors before runtime. In short, TypeScript is a "Tool" that helps developers write better code!

# Installation
1. Download typescript (complier) globally on the computer
2. run `$ tsc ` to compile ts to js
   
# Overview
## What TS addes 
1. Types!
2. Next-gen JS Features (compiled down for older Browsers)
3. Non-JS Features like Interfaces or Generics
4. Meta-Programming Features like Decorators
5. Rich Configuration Options
6. Modern Tooling that helps even in non-TypeScript projects (like the error hint embedded in VS code) Under the hood, it employs the TS. 
