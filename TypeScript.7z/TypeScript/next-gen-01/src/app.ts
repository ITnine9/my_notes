// Code goes here!
// parameter b has a default value
const add = (a: number, b: number = 2) => a + b;

const printRes: (a: number | string) => void = output => console.log(output);

printRes(add(5));

const btn = document.querySelector('button')

if (btn) {
    btn.addEventListener('click', () => console.log('Button clicked!'))
}

// spread operator 
const hobbies = ['hiking', 'reading']

const activeHobbies = ['jogging']

activeHobbies.push(...hobbies, 'lala')

console.log(activeHobbies)

// rest parameters
const addAny = (...args: number[]) => {
    return args.reduce((acc, curr) => acc + curr)
}

console.log('addAny result: ', addAny(1, 2, 3))

// Array & Object Desturcturing




