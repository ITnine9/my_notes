# Watch Mode
You don't have to re-compile the ts file after every change manually by use the --watch option
`$ tsc app.ts -w`
or
`$ tsc app.ts --watch`

# Create a TS projcet
`$ tsc --init`
This will create a tsconfig file.

Than run `$ tsc -w` to watch all ts changes in the project.

# Including & Excluding Files
Add the following code to tsconfig.ts
```
  "exclude": [
    "node_modules" // This is default behavior, only put it here for the demonstration
  ], 
  "include": [
    "app.ts"
  ],
  "files": [
    // This only accepts files not folders like the 'include' option
  ]
```

These options are the same level as "compilerOption".

include minus exclude = only matter files

# Compiler Options
Most of the options are not important. 

## change es version
es5 => es2016
```
{
  "compilerOptions": {
    "target": "es2016",           
    }
}
```
If you don't specify the version, the default one will be es3.

## library setting
```
"lib": [
      "DOM",
      "ES6",
      "DOM.Iterable",
      "ScriptHost"
      ],     
```
To include the document api from the browser.
All of the above settings are default.

# Other compilation & configuration option
* allowJs (to complie js file also)
* checkJs (if you have some vanilla js files along with the ts files, and want to check them for errors)
* jsx 
* declaration (for creating modules for others to use, it will generate .d.ts file)
* declarationMap

## sourceMap option
It supports the development and debugging. The .map file will be created to help sources tool in browser for you to debug. In the sources menu you could see the original ts file, thus you are able to create a breakpoint for debugging.

# specify a folder to contain emitted files (compiled js files)
`$ "outDir": "./dist"`

`$ "rootDir": "./src",`

`$ "removeComments": true,`

# noEmitOnError
`$ "noEmitOnError": true`
If there is an error in a file, then all the files will not be emitted.

# Strict Compilation 
`$ "strict": true,` 
To set all the strict options on.

`$ "noImplicitAny": true,`                       /* Enable error reporting for expressions and declarations with an implied 'any' type.
The parameter of function cann't be left as any type, the type must be specified. However, the variable declaration could be.

`$ "strictNullChecks": true,`                         /* When type checking, take into account 'null' and 'undefined'. */
Like the btn in `$ document.querySelector('button')!` 
If there is no '!' at the end the of line, an error will be displayed as btn might be null.

Exclamation operator acts as a non-null assertion operator.

`$ "strictBindCallApply": true`                      /* Check that the arguments for 'bind', 'call', and 'apply' methods match the original function.

# Code Quality Options
```
    // "noUnusedLocals": true,                           /* Enable error reporting when local variables aren't read. */
    // "noUnusedParameters": true,                       /* Raise an error when a function parameter isn't read. */
    // "noImplicitReturns": true,                        /* Enable error reporting for codepaths that do not explicitly return in a function. */
```
   
# debugger
You could use Javascript Debugger to debug the ts file. 
Make sure that you turn on the sourceMap option in compiler setting.