# Core Types
1. number
2. string
3. boolean

They work the same way as in TS.

# Difference between JS Type and TS Type
JS is dynamic typed, however TS is static typed. In other words, the type of variable in js can be changed during the runtime, while TS type could not. Therefore, you could catch the type error during development. Noted that TS is only able to help you at development not the runtime, as the logic is not implemented in the engine.

__The core primitive types in TS are all lowercase.__

# Type script does a pretty good job as type inference
So we don't have to define the type when declare a constant or a varable. (save your efforts)
Once you declare a variable or constant the type of it is already determined by TS. If you change the type of the value, you will get errors.

# Object Type
TS will notice you the undefine object property.
When you declare an object, it is concrete which means the type and the structure of object's propertie are defined. If you add any undefined properties to the object, TS will warn you.

## Nested object also is supported by TS

# Arrays
string[]

# Tuples (Advanced Type)
[number, string]

```
const person: {
    name: string;
    age: number;
    hobbies: string[];
    role: [number, string] // tuple type
} = {
    name: 'Jeff', 
    age: 30,
    hobbies: ['gaming', 'hiking'],
    role: [0, 'admin']
};
```
The tuple length is fixed. 

Note that ` array.push()` is allowed as an exception. 

# Enums
Enums are only added by TS. It gaves you a enumerated list. 
It is a custom type.

```
// the follow is the enum default
enum Role {ADMIN, READ_ONLY_USER, AUTHOR}; 
// enum Role {ADMIN = 100, READ_ONLY_USER = 200, AUTHOR = 'AUTHOR'};

const person = {
    name: 'Jeff', 
    age: 30,
    hobbies: ['gaming', 'hiking'],
    role: Role.ADMIN
};

if (person.role === Role.ADMIN) {
    console.log('The user is admin.');
}
```

# Any
Any tyes means you can store any type into the variable.
Try to avoid this any type as always as possible.

# Union types
To make TS accepts multiple types.
```
function combine(input1: number | string, input2: number | string) {
    let result;
    if (typeof input1 === "number" && typeof input2 === "number") {
        result = input1 + input2;
    } else {
        result = input1.toString() + input2.toString();
    }
    return result;
}

const concatName = combine('Jeff', 'Elli');
const combineHeight = combine(180, 190);
console.log(concatName);
console.log(combineHeight);
```

You will always write certain method to deal with different types in your union types like the above example.

# Literal types
Use it when you know the exact value of the variable.
```
function combine(input1: number | string, input2: number | string, resultConversion: 'as-number' | 'as-string') {
    let result;
    if (typeof input1 === "number" && typeof input2 === "number" 
        || resultConversion === "as-number") {
        result = +input1 + +input2;
    } else {
        result = input1.toString() + input2.toString();
    }
    return result;
}

const concatName = combine('Jeff', 'Elli', 'as-string');
const combineHeight = combine(180, 190, 'as-number');
const combineStringHeight = combine('180', '190', 'as-number');
```
You could combine union type and literal type together.

# Type aliases / custom types
```
type Combinable = number | string;
type ConversionDescriptor = 'as-number' | 'as-string';
function combine(input1: Combinable, input2: Combinable, resultConversion: ConversionDescriptor) {
    let result;
    if (typeof input1 === "number" && typeof input2 === "number" 
        || resultConversion === "as-number") {
        result = +input1 + +input2;
    } else {
        result = input1.toString() + input2.toString();
    }
    return result;
}
```

```
type User = { name: string; age: number };
const u1: User = { name: 'Max', age: 30 }; // this works!
```

# Funtion return type & 'void'
If you don't want to reture anything from a function, you can explicitly use 'void' type.
```
function printRes(n: number): void {
    console.log(n);
}
```

# Functions as types
```
function add(n1: number, n2: number) {
    return n1 + n2;
}

// let combineValues: Function;
let combineValues: (n1: number, n2: number) => number;

combineValues = add;
```

# Callbacks
```
function addAndHandle(n1: number, n2: number, cb: (num: number) => void) {
    const res = n1 + n2;
    cb(res);
}

addAndHandle(11, 20, (result) => {
    console.log(result);
});
```
Noted that the void denoted in cb return type doesn't force you not to return anything, it just acts as an indicator you that the main function will not use the return value from the cb function.

# unknown type
The unknow type is better than the any type, because it give you some type restriction check. When you don't know the type of a vairable but do know what to do when comes the certain type, you could use unknown type.

The following commented out code does not work.
```
let userInput: unknown;
let userName: string;

userInput = 'Jeff'
// userName = userInput;

if (typeof userInput === 'string') {
    userName = userInput;
    console.log(userName);
}
```

# never type
When the function actually don't return anything including the default return value 'undefined', you should use never as the funtion return type.

```
function generateError(message: string, code: number): never {
    throw {message: message, errorCode: code};
}

console.log(generateError('Page not found', 404));
```
