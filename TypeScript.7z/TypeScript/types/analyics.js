"use strict";
console.log('yesland!');
