let userInput: unknown;
let userName: string;

userInput = 'Jeff awesome sure!'
// userName = userInput;

if (typeof userInput === 'string') {
    userName = userInput;
    console.log(userName);
}

function generateError(message: string, code: number): never {
    throw {message: message, errorCode: code};
}

console.log(generateError('Page not found!!', 504));
