// const person: {
//     name: string;
//     age: number;
//     hobbies: string[];
//     role: [number, string]
// } = {
//     name: 'Jeff', 
//     age: 30,
//     hobbies: ['gaming', 'hiking'],
//     role: [0, 'admin']
// };
// the follow is the enum default
enum Role {ADMIN, READ_ONLY_USER, AUTHOR}; 
// enum Role {ADMIN = 100, READ_ONLY_USER = 200, AUTHOR = 'AUTHOR'};

const person = {
    name: 'Jeff', 
    age: 30,
    hobbies: ['gaming', 'hiking'],
    role: Role.ADMIN
};

for (const hobby of person.hobbies) {
    console.log(hobby.toUpperCase());
}

if (person.role === Role.ADMIN) {
    console.log('The user is admin.');
}
