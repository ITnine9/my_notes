console.log("Beginning the the script!");

abstract class Shop {
    // name: string;
    // make products field private, thus not accessible from direct call
    // protected modifier make the field private but at the same time available in child classes
    static fiscalYear = 2021;
    protected products: string[] = ['shoes', 'hoddies', 'gloves'];

    // public keyword in constructor is mandatory, must be declared explictly
    constructor(public name: string, protected readonly id: string) {
        // this.name = n;
    }

    static createProduct(name: string) {
        return {name: name};
    }

    get lastProduct() {
        if (this.products.length === 0) {
            throw new Error('There is no product.');
        }
        return this.products[this.products.length - 1];
    }

    set lastProduct(value: string) {
        if (!value) {
            throw new Error ('Please pass a valid value!');
        }
        this.addProduct(value);
    }



    // this keyword put in the parameter location is an indicator in TS
    abstract describe(this: Shop): void;

    addProduct(name: string) {
        this.products.push(name);
    }

    displayProduct() {
        console.log(this.products.length);
        console.log(this.products);
    }
}

class SportsShop extends Shop {
    private static instance: SportsShop;

    // to make a singleton
    private constructor(id: string, private genre: string[]) {
        super('Sports', id);
    }

    static getInstance() {
        // this keyword in static method refers to static properties
        if (this.instance) {
            return this.instance;
        } 
        return new SportsShop('S03', ['Hiking', 'diving', 'Spelunky2']);
    }

    describe(): void {
        console.log(`Sports Shop - ${this.id}:   ${this.name}`);
    }
    
    addProduct(name: string): void {
        if (name === 'socks') return;
        this.products.push(name);
    }

    addGenre(g: string) {
        this.genre.push(g);
    }

    printGenre() {
        console.log(this.genre);
    }
}

// const rebel_sport = new SportsShop('S02', ['Hiking', 'diving', 'Spelunky2']);
const rebel_sport = SportsShop.getInstance();
const light_sport = SportsShop.getInstance();
console.log(rebel_sport, light_sport);
// rebel_sport.describe();
// rebel_sport.addGenre('Footbal');
// rebel_sport.printGenre();

// rebel_sport.addProduct('socks');
// rebel_sport.addProduct('Goggle');
// rebel_sport.displayProduct();

// the following is how you pass a value to setter 
rebel_sport.lastProduct = 'cue stick';
rebel_sport.describe();
console.log('last product ' + rebel_sport.lastProduct);
console.log(Shop.createProduct('pants'), Shop.fiscalYear);


// const clothes_shop = new Shop('Clothes', 'S01');

// // const another_shop = { name: 'lala',describe: clothes_shop.describe }
// // another_shop.describe();

// clothes_shop.describe();
// clothes_shop.addProduct('hats1');
// clothes_shop.displayProduct();