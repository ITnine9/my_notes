console.log("Beginning the the script!");

type Admin = {
    name: string;
    privileges: string[];
}

type Employee = {
    name: string;
    startDate: Date;
}

type ElevatedEmployee = Admin & Employee;

const user: ElevatedEmployee = {
    name: 'Jeff',
    privileges: ['create-database'],
    startDate: new Date()
}

type Combinable = string | number;
type Numeric = number | boolean;

type Universal = Combinable & Numeric;

const a: Universal = 2;

// function overload
function add(a: number, b: number): number;
function add(a: string, b: string): string;
function add(a: string, b: number): string;
function add(a: number, b: string): string;
function add(a: Combinable, b: Combinable) {
    // typeof as type guard
    if (typeof a === 'string' || typeof b === 'string') {
        return a.toString() + b.toString();
    }
    return a + b;
}

let result = add('1', 2);

type unknownEmployee = Admin | Employee;

function printEmployeeInformation(emp: unknownEmployee) {
    console.log(emp.name);
    // in keyword as type guard
    if ('privileges' in emp) {
        console.log(emp.privileges);
    }

    if ('startDate' in emp) {
        console.log(emp.startDate);
    }
}

const employee_a: unknownEmployee = {
    name: 'Jeff',
    privileges: ['create-account']
}

printEmployeeInformation(employee_a);

class Car {
    drive() {
        console.log('Driving...');
    }
}

class Truck {
    drive() {
        console.log('Driving a truck...');
    }

    loadCargo() {
        console.log('Loading Cargo...');
    }
}

type Vehicle = Car | Truck;

let myTruck: Vehicle = new Truck();
let myCar: Vehicle = new Car();

function driveVehicle(v: Vehicle) {
    // using instanceof as type guard
    v.drive();
    if (v instanceof Truck) {
        v.loadCargo();
    }
}

driveVehicle(myTruck);
driveVehicle(myCar);

interface bird {
    type: 'bird';
    flyingSpeed: number;
}

interface Horse {
    type: 'horse';
    runningSpeed: number;
}

// discriminated unions
type Animal = bird | Horse;

function moveAnimal(animal: Animal) {
    let speed: number;
    switch (animal.type) {
        case 'bird':
            speed = animal.flyingSpeed;
            console.log('Flying at speed ' + speed);
            break;
        case 'horse':
            speed = animal.runningSpeed;
            console.log('Running at speed ' + speed);
            break;
    }
}

const myBird: Animal = { type: 'bird', flyingSpeed: 30 }

moveAnimal(myBird)


// Type Casting
// const userInputElement = <HTMLInputElement>document.querySelector('#user-input')!;
// const userInputElement = document.querySelector('#user-input')! as HTMLInputElement;
const userInputElement = document.querySelector('#user-input');

if (userInputElement) {
    (userInputElement as HTMLInputElement).value = 'xixi';
}

// index properties
interface ErrorContainer {
    [prop: string]: string;
}

const errorBag: ErrorContainer = {
    email: 'Not a valid email',
    username: 'username must start with a capital character'
}

// Optional Chaining
const fetchedUserData = {
    name: 'Jeff',
    age: 30,
    // job: {title: 'developer'}
}

console.log(fetchedUserData.job?.title);


// Nullish Coalescing
const userInput = 0;

const res = userInput ?? 'Default';

