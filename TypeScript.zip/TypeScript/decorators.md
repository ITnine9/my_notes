# Definition
This feature is very useful for meta-programming. It means it is particular used for make code that can be easily used by other developers.
It gurarantees that the class or method of it is used correctly, also same hidden transmission.
Decorators in general are all about classes.

```
function Logger(constructor: Function) {
    console.log('Logging...')
    console.log(constructor)
}

@Logger
class Person {
    name = "Jeff"

    constructor() {
        console.log('Creating person object...')

    }
}

const jeff = new Person()
console.log(jeff)
```

Note: The decorator is executed once it is attached to a class.

## Decortar Factory
It allows you to pass extra parameter.

```
// decorator factory
function Logger(LogString: string) {
    return function(constructor: Function) {
        console.log(LogString)
        console.log(constructor)
    }
}

@Logger('Logging - Person')
class Person {
    name = "Jeff"

    constructor() {
        console.log('Creating person object...')

    }
}
```

More useful example:
```
@WithTemplate('<h1>My person object</h1>', 'app')
class Person {
    name = "Jeff"

    constructor() {
        console.log('Creating person object...')

    }
}

function WithTemplate(template: string, hookId: string) {
    // use 'underscore' symbol to tell TS that you don't care about the paramter
    return function(constructor: any) {
        const hookEle = document.querySelector('#app')
        if (hookEle) {
            const person = new constructor()
            hookEle.querySelector('h1')!.textContent = person.name
        }
    }
}
```

## decorator execution order
The factory decorators execute from bottom to up, while the normal decorators work the same way as normal.

## class property decorator
It takes two parameters, and it can be applied to both instance property and static property.
The target could be either the instance object or the class constructor
```
function Log(target: any, propertyName: string | Symbol) {
    console.log('Property Decorator!')
    console.log(target, propertyName)
}

class Product {

    @Log
    title: string;
    private _price: number;

    set price(val: number) {
        if (val > 0 ) {
            this._price = val
        } else {
            throw new Error('Invalid price - should be positive!')
        }
    }

    constructor( title: string,  price: number) {
        this.title = title
        this._price = price
    }
    // constructor(public title: string, private _price: number) {

    // }

    getPriceWithTax(tax: number) {
        return this._price * (1 + tax)
    }

}
```

## Decorators for class accessors (getter & setter) and methods
```
function Log3(target: any, name: string | Symbol, descriptor: PropertyDescriptor) {
    console.log('Method Decorator!') // or console.log('Accessor Decorator!')
    console.log(target)
    console.log(name)
    console.log(descriptor)
}
```

## Decorator for parameter
It has a unique parameter call postion as usual starting at 0. The name will be the function name.
```
function Log4(target: any, name: string | Symbol, position: number) {
    console.log('Parameter Decorator!')
    console.log(target)
    console.log(name)
    console.log(position)
}
```


## Returning a class in a class decorator
A 'class' keyword is a syntax suger for a constructor function. You can also reture something in a method decorator.
'_' symbol dedicates that you know the parameter will not be used.
Now the logic in decorator will be executed when the object has been initiated.
```
function WithTemplate(template: string, hookId: string) {
    // use 'underscore' symbol to tell TS that you don't care about the paramter
    return function<T extends {new (...arg: any[]): {name: string}}>(originalConstructor: T) {
        return class extends originalConstructor {
            constructor(..._: any[]) {
                super()
                console.log('template rendering')
                const hookEle = document.getElementById(hookId)
                if (hookEle) {
                    hookEle.innerHTML = template
                    hookEle.querySelector('h1')!.textContent = this.name
                }
            }
        }
    }
}
```

## decorators which can return something
1. class
2. accessors
3. methods

### Method and Accessor decorator
You can reture `PropertyDescriptor` in these decorators.

The 'this' in the getter function binds value to its concrete object. 
```
function Autobind(_target: any, _methodName: string, descriptor: PropertyDescriptor) {
    const originalMethod = descriptor.value
    const adjDescriptor: PropertyDescriptor = {
        configurable: true,
        enumerable: false,
        get() {
            const boundFn = originalMethod.bind(this)
            return boundFn
        }
    }
    return adjDescriptor
}

class Print {
    message = "This works"

    @Autobind
    showMessage() {
        console.log(this.message)
    }
}

const p = new Print()

const button = document.querySelector('button')!
button.addEventListener('click', p.showMessage)
```

## Some third-party package and libraries use decorators
1. Angular
2. class-validator
3. nest.js (node.js framework)