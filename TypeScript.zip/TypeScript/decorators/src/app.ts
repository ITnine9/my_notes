console.log("Beginning the the script!");

// function Logger(constructor: Function) {
//     console.log('Logging...')
//     console.log(constructor)
// }

// factory decorator
function Logger(LogString: string) {
    return function(constructor: Function) {
        console.log(LogString)
        console.log(constructor)
    }
}

@Logger('Logging - Person')
@WithTemplate('<h1>My person object</h1>', 'app')
class Person {
    name = "Jeff"

    constructor() {
        console.log('Creating person object...')

    }
}

function WithTemplate(template: string, hookId: string) {
    // use 'underscore' symbol to tell TS that you don't care about the paramter
    return function<T extends {new (...arg: any[]): {name: string}}>(originalConstructor: T) {
        return class extends originalConstructor {
            constructor(..._: any[]) {
                super()
                console.log('template rendering')
                const hookEle = document.getElementById(hookId)
                if (hookEle) {
                    hookEle.innerHTML = template
                    hookEle.querySelector('h1')!.textContent = this.name
                }
            }
        }
    }
}


// function WithTemplate(template: string, hookId: string) {
//     // use 'underscore' symbol to tell TS that you don't care about the paramter
//     return function(constructor: any) {
//         console.log('withTemplate logging')
//         const hookEle = document.getElementById(hookId)
//         if (hookEle) {
//             const person = new constructor()
//             hookEle.innerHTML = template
//             hookEle.querySelector('h1')!.textContent = person.name
//         }
//     }
// }

// const jeff = new Person()
// console.log(jeff)

function Log(target: any, propertyName: string | Symbol) {
    console.log('Property Decorator!')
    console.log(target, propertyName)
}

function Log2(target: any, name: string | Symbol, descriptor: PropertyDescriptor) {
    console.log('Accessor Decorator!')
    console.log(target)
    console.log(name)
    console.log(descriptor)
}

function Log3(target: any, name: string | Symbol, descriptor: PropertyDescriptor) {
    console.log('Method Decorator!')
    console.log(target)
    console.log(name)
    console.log(descriptor)
}

function Log4(target: any, name: string | Symbol, position: number) {
    console.log('Parameter Decorator!')
    console.log(target)
    console.log(name)
    console.log(position)
}

class Product {

    @Log
    title: string;
    private _price: number;

    @Log2
    set price(val: number) {
        if (val > 0 ) {
            this._price = val
        } else {
            throw new Error('Invalid price - should be positive!')
        }
    }

    constructor( title: string,  price: number) {
        this.title = title
        this._price = price
    }
    // constructor(public title: string, private _price: number) {

    // }
    @Log3
    getPriceWithTax(@Log4 tax: number) {
        return this._price * (1 + tax)
    }

}

// returning something from method decorator
function Autobind(_target: any, _methodName: string, descriptor: PropertyDescriptor) {
    const originalMethod = descriptor.value
    const adjDescriptor: PropertyDescriptor = {
        configurable: true,
        enumerable: false,
        get() {
            const boundFn = originalMethod.bind(this)
            return boundFn
        }
    }
    return adjDescriptor
}

class Print {
    message = "This works"

    @Autobind
    showMessage() {
        console.log(this.message)
    }
}

const p = new Print()

const button = document.querySelector('button')!
button.addEventListener('click', p.showMessage)

// validation example
interface ValidatorConfig {
    // property will be the constructor name
    [property: string]: {
        [validatableProp: string]: string[] // ['required', 'positive']
    }
}

const registeredValidators: ValidatorConfig = {}

function Required(target: any, propName: string) {
    registeredValidators[target.constructor.name] = {
        ...registeredValidators[target.constructor.name], 
        [propName]: [ ...(registeredValidators[target.constructor.name]?.[propName] ?? []), 'required']
    }
}

function PositiveNumber(target: any, propName: string) {
    registeredValidators[target.constructor.name] = {
        ...registeredValidators[target.constructor.name],
        [propName]: [ ...(registeredValidators[target.constructor.name]?.[propName] ?? []), 'positive']
    }
}

function validate(obj: any) {
    const objValidatorConfig = registeredValidators[obj.constructor.name]
    if (!objValidatorConfig) {
        return true
    }
    let isValid = true
    for (const prop in objValidatorConfig) {
        for (const validator of objValidatorConfig[prop]) {
            switch (validator) {
                case 'required':
                    isValid = isValid && !!obj[prop]
                    break
                case 'positive':
                    isValid = isValid && obj[prop] > 0
                    break
            }
        }
    }
    return isValid;
}

class Course {
    @Required
    title: string

    @PositiveNumber
    price: number

    constructor(t: string, p: number) {
        this.title = t
        this.price = p
    }
}

const form = document.querySelector('form')!
form.addEventListener('submit', event => {
    event.preventDefault()
    const titleEl = document.querySelector('#title')! as HTMLInputElement
    const priceEl = document.querySelector('#price')! as HTMLInputElement

    const title = titleEl.value
    const price = +priceEl.value


    const course = new Course(title, price)
    if ( !validate(course) ) {
        throw new Error('Title or price invalied!')
    }

    console.log('course:', course)
})


