import { ProjectInput } from "./components/project-input.js";
import { Projectlist } from "./components/project-list.js";


// if ('content' in document.createElement('template')!) {
//     const body = document.querySelector('body')!
//     const form = document.querySelector('#project-input')!
//     if (form instanceof HTMLTemplateElement) {
//         const clone = form.content.cloneNode(true)
//         body.appendChild(clone)

//     }

// }

// class ProjectInput {
//     templateElement: HTMLTemplateElement | null

//     constructor() {
//         const templateEl = document.querySelector('#project-input') as HTMLTemplateElement
//         if (templateEl) {
//             this.templateElement = templateEl
//         } else {
//             this.templateElement = null
//         }
//     }
// }

namespace App {

    // class SingleProject {
    //     templateElement: HTMLTemplateElement;
    //     hostElement: HTMLDivElement;
    //     activeListElement: HTMLUListElement;
    //     element: HTMLElement;

    //     title: string;
    //     description: string;
    //     people: number;

    //     constructor(title: string, description: string, people: number) {
    //         this.templateElement = document.querySelector('#single-project')! as HTMLTemplateElement;
    //         this.hostElement = document.querySelector('#app')! as HTMLDivElement;
    //         this.activeListElement = this.hostElement.querySelector('#active-projects-list') as HTMLUListElement;
    //         const importedNode = document.importNode(this.templateElement.content, true);

    //         this.element = importedNode.firstElementChild as HTMLLIElement;
    //         this.title = title;
    //         this.description = description;
    //         this.people = people;

    //         this.renderListItem();
    //     }

    //     private renderListItem() {
    //         this.element.textContent = `Title: ${this.title}, Description: ${this.description}, people: ${this.people}`;
    //         this.activeListElement.insertAdjacentElement('beforeend', this.element);
    //     }
    // }

    

     new ProjectInput('project-input', 'app', true, 'user-input');

     new Projectlist('active');
     new Projectlist('finished');
}


