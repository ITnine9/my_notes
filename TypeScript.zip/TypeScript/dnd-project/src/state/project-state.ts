import { Project } from "../models/project.js";
import { ProjectStatus } from "../models/project.js";

type Listener<T> = (items: T[]) => void;

class State<T> {
    protected listners: Listener<T>[] = [];
    addListener(listenerFn: Listener<T>) {
        this.listners.push(listenerFn);
    }
}



// project state management 
export class ProjectState extends State<Project> {
    // private listners: Listener[] = [];
    private static instance: ProjectState;
    private projects: Project[] = [];

    private constructor() {
        super();
    }
    // singleton
    static getInstance() {
        if (this.instance) return this.instance;
        this.instance = new ProjectState();
        return this.instance;
    }

    // addListener(listenerFn: Listener) {
    //     this.listners.push(listenerFn);
    // }

    addProject(title: string, description: string, numOfPeople: number) {
        // const newProject = {
        //     id: Math.random().toString(),
        //     title,
        //     description,
        //     people: numOfPeople
        // };
        const newProject = new Project(Math.random().toString(), title, description, numOfPeople, ProjectStatus.Active);
        this.projects.push(newProject);
        this.updataListeners();
    }

    moveProject(projectId: string, newStatus: ProjectStatus) {
        const project = this.projects.find(prj => prj.id === projectId);
        if (project && project.status !== newStatus) {
            project.status = newStatus;
            this.updataListeners();
        }
    }

    private updataListeners() {
        for (const listenerFn of this.listners) {
            listenerFn(this.projects.slice());
        }
    }
}

console.log('project state initiating only once!');

export const projectState = ProjectState.getInstance();
