# Definition
The generic type is connected to other types. And it is flexible about which type the other type is.

The following types are the built-in generic type
1. Array type
2. promise type

```
const names: Array<string> = []; // string []
// names[0].split(' ');

const promise: Promise<string> = new Promise((resolve, reject) => {
    setTimeout(() => {
        resolve('This is done!');
    }, 2000);
})

promise.then(res => {
    res.split(' ');
})
```

You can build your own generics function or class.

# generics type constraints

```
function merge<T extends object, U extends object>(objA: T, objB: U) {
    return Object.assign(objA, objB);
}
```

The following code constrains the parameter to have length property.
```
interface Lengthy {
    length: number
}

function countAndDescribe<T extends Lengthy>(element: T): [T, string] {
    let descriptionText = 'Got no value';
    if (element.length === 1) {
        descriptionText = 'Got 1 element';
    } else if (element.length > 1) {
        descriptionText = 'Got ' + element.length +' elements';
    }

    return [element, descriptionText]; 
}

console.log(countAndDescribe('hello, world'));
console.log(countAndDescribe(['apple', 'banana']));
console.log(countAndDescribe([]));
```

# keyof constraint
When you want to retrict the certain type of the key of a specific object.
```
function extractAndPrint<T extends object, U extends keyof T>(obj: T, key: U) {
    return 'Value: ' + obj[key]
}

console.log(extractAndPrint({name: 'Jeff'}, 'name'))
```

# generic class
It only works better with primitive data types like number, string and boolean in the following example.
```
class DataStorage<T> {
    private data: T[] = [];

    addItem(item: T) {
        this.data.push(item)
    }

    removeItem(item: T) {
        if (this.data.indexOf(item) === -1) return
        this.data.splice(this.data.indexOf(item), 1)
    }

    getItems() {
        return [...this.data]
    }
}

const textStorage = new DataStorage<string>()

textStorage.addItem('Footbal')
textStorage.addItem('pool')
textStorage.removeItem('Football')
textStorage.addItem('tennis')
textStorage.addItem('table tennis')

console.log(textStorage.getItems())

const numberStorage = new DataStorage<number>()
numberStorage.addItem(10)
numberStorage.addItem(120)
numberStorage.addItem(99)
console.log(numberStorage.getItems())
```

# generic utility type
They are built-ins. However, they don't exist in vanila JS.
## Partial
The Partial generic type is used to tell TS that the object is not the final version yet. The type structure is temporary and optional.
```
interface CourseGoal {
    title: string,
    description: string,
    completeUntil: Date
}

function createCourseGoal(title: string, description: string, date: Date): CourseGoal {
    // return {title, description, completeUntil: date}
    let courseGoal: Partial<CourseGoal> = {}
    courseGoal.title = title
    courseGoal.description = description
    courseGoal.completeUntil = date
    return courseGoal as CourseGoal
}
```

## Readonly
It does not allow you to modify the variable.
```
// Readonly generic type
let arr: Readonly<string[]> = ['Jeff', 'John']
// arr.push('Joel')
// arr.pop()
```

There are many utility types to use.
[Utility Types](https://www.typescriptlang.org/docs/handbook/utility-types.html)

## Difference between Union Types and Generic Types
The generic types lock in a type, while union types accpect flexible kinds of type.
