"use strict";
console.log("Beginning the the script!");
const names = []; // string []\
// names[0].split(' ');
const promise = new Promise((resolve, reject) => {
    setTimeout(() => {
        resolve('This is done!');
    }, 2000);
});
promise.then(res => {
    res.split(' ');
});
function merge(objA, objB) {
    return Object.assign(objA, objB);
}
const mergedObj = merge({ name: 'Jeff' }, { age: 30 });
console.log(mergedObj.name);
function countAndDescribe(element) {
    let descriptionText = 'Got no value';
    if (element.length === 1) {
        descriptionText = 'Got 1 element';
    }
    else if (element.length > 1) {
        descriptionText = 'Got ' + element.length + ' elements';
    }
    return [element, descriptionText];
}
console.log(countAndDescribe('hello, world'));
console.log(countAndDescribe(['apple', 'banana']));
console.log(countAndDescribe([]));
// keyof constraint
function extractAndPrint(obj, key) {
    return 'Value: ' + obj[key];
}
console.log(extractAndPrint({ name: 'Jeff' }, 'name'));
// generic class type
// class DataStorage<T extends number | string | boolean> {
class DataStorage {
    constructor() {
        this.data = [];
    }
    addItem(item) {
        this.data.push(item);
    }
    removeItem(item) {
        if (this.data.indexOf(item) === -1)
            return;
        this.data.splice(this.data.indexOf(item), 1);
    }
    getItems() {
        return [...this.data];
    }
}
const textStorage = new DataStorage();
textStorage.addItem('Footbal');
textStorage.addItem('pool');
textStorage.removeItem('Football');
textStorage.addItem('tennis');
textStorage.addItem('table tennis');
console.log(textStorage.getItems());
const numberStorage = new DataStorage();
numberStorage.addItem(10);
numberStorage.addItem(120);
numberStorage.addItem(99);
console.log(numberStorage.getItems());
// the following lines of comment-out code doesn't work
const objStorage = new DataStorage();
// objStorage.addItem({name: 'jeff'})
// objStorage.addItem({name: 'john'})
// objStorage.removeItem({name: 'jeff'})
// console.log(objStorage.getItems())
const jeffObj = { name: 'jeff' };
objStorage.addItem(jeffObj);
objStorage.addItem({ name: 'john' });
objStorage.removeItem(jeffObj);
console.log(objStorage.getItems());
function createCourseGoal(title, description, date) {
    // return {title, description, completeUntil: date}
    let courseGoal = {};
    courseGoal.title = title;
    courseGoal.description = description;
    courseGoal.completeUntil = date;
    return courseGoal;
}
// Readonly generic type
let arr = ['Jeff', 'John'];
// arr.push('Joel')
// arr.pop()
