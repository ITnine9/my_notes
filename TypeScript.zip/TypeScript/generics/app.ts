console.log("Beginning the the script!");
const names: Array<string> = []; // string []\
// names[0].split(' ');

const promise: Promise<string> = new Promise((resolve, reject) => {
    setTimeout(() => {
        resolve('This is done!');
    }, 2000);
})

promise.then(res => {
    res.split(' ');
})

function merge<T extends object, U extends object>(objA: T, objB: U) {
    return Object.assign(objA, objB);
}

const mergedObj = merge({ name: 'Jeff' }, { age: 30 });

console.log(mergedObj.name);

interface Lengthy {
    length: number
}

function countAndDescribe<T extends Lengthy>(element: T): [T, string] {
    let descriptionText = 'Got no value';
    if (element.length === 1) {
        descriptionText = 'Got 1 element';
    } else if (element.length > 1) {
        descriptionText = 'Got ' + element.length + ' elements';
    }

    return [element, descriptionText];
}

console.log(countAndDescribe('hello, world'));
console.log(countAndDescribe(['apple', 'banana']));
console.log(countAndDescribe([]));

// keyof constraint
function extractAndPrint<T extends object, U extends keyof T>(obj: T, key: U) {
    return 'Value: ' + obj[key]
}

console.log(extractAndPrint({name: 'Jeff'}, 'name'))

// generic class type
// class DataStorage<T extends number | string | boolean> {
class DataStorage<T> {
    private data: T[] = [];

    addItem(item: T) {
        this.data.push(item)
    }

    removeItem(item: T) {
        if (this.data.indexOf(item) === -1) return
        this.data.splice(this.data.indexOf(item), 1)
    }

    getItems() {
        return [...this.data]
    }
}

const textStorage = new DataStorage<string>()

textStorage.addItem('Footbal')
textStorage.addItem('pool')
textStorage.removeItem('Football')
textStorage.addItem('tennis')
textStorage.addItem('table tennis')

console.log(textStorage.getItems())

const numberStorage = new DataStorage<number>()
numberStorage.addItem(10)
numberStorage.addItem(120)
numberStorage.addItem(99)
console.log(numberStorage.getItems())

// the following lines of comment-out code doesn't work
const objStorage = new DataStorage<object>()
// objStorage.addItem({name: 'jeff'})
// objStorage.addItem({name: 'john'})
// objStorage.removeItem({name: 'jeff'})
// console.log(objStorage.getItems())

const jeffObj = {name: 'jeff'}
objStorage.addItem(jeffObj)
objStorage.addItem({name: 'john'})
objStorage.removeItem(jeffObj)
console.log(objStorage.getItems())

// Partial generic type
interface CourseGoal {
    title: string,
    description: string,
    completeUntil: Date
}

function createCourseGoal(title: string, description: string, date: Date): CourseGoal {
    // return {title, description, completeUntil: date}
    let courseGoal: Partial<CourseGoal> = {}
    courseGoal.title = title
    courseGoal.description = description
    courseGoal.completeUntil = date
    return courseGoal as CourseGoal
}

// Readonly generic type
let arr: Readonly<string[]> = ['Jeff', 'John']
// arr.push('Joel')
// arr.pop()












