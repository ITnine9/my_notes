# Writing Modular Code
Splitting your code into modules
Two options to organize code in multiple files

1. Namespaces & File Bundling
    Use "namespace" code syntax to group code
    Per-file or bundled compliation is possible (less imports to manage)
2. ES6 Imports/Exports
    Use ES6 import/export syntax
    Per-file compilation but single <script> import
    Bundling via third-part tools (e.g. Webpack) is possible!