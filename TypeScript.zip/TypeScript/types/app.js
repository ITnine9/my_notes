"use strict";
let userInput;
let userName;
userInput = 'Jeff awesome sure!';
// userName = userInput;
if (typeof userInput === 'string') {
    userName = userInput;
    console.log(userName);
}
function generateError(message, code) {
    throw { message: message, errorCode: code };
}
console.log(generateError('Page not found!!', 504));
