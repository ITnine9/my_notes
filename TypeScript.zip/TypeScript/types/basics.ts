console.log("Beginning the the script!");

function foo(num1: number, num2: number, showResult: boolean, phrase: string) {
    const result = num1 + num2;
    if (showResult) {
        console.log(phrase + result)
    } else {
        return result;
    }
}

const a = 5, b = 2.8;
const printResult = true;
const resultPhrase = "The result is: "
foo(a, b, printResult, resultPhrase);