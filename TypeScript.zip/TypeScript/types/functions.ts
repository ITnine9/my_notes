// function add(n1: number, n2: number) {
//     return n1 + n2;
// }

// function printRes(n: number): void {
//     console.log(n);
// }

// // let combineValues: Function;
// let combineValues: (n1: number, n2: number) => number;

// combineValues = add;



// printRes(add(10, 5));
// printRes(combineValues(10, 5));

function addAndHandle(n1: number, n2: number, cb: (num: number) => void) {
    const res = n1 + n2;
    cb(res);
}

addAndHandle(11, 20, (result) => {
    console.log(result);
});