Hi from **Happy Potter** staight from `.appstore/index.md`!

Please change the content of this file to provide helpful information to user in the App Store Portal.  
Visit [this Developer Documentation page](https://developer.docs.basf.net/appstore/portal/#info) to learn how to change this content.




