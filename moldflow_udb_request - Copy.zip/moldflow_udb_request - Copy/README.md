# moldflow_udb_request

<!-- badges: start -->
[![build status](https://gitlab.roqs.basf.net/WUZ35/moldflow_udb_request/badges/development/pipeline.svg)](https://gitlab.roqs.basf.net/WUZ35/moldflow_udb_request/pipelines?scope=branches)
[![coverage report](https://gitlab.roqs.basf.net/WUZ35/moldflow_udb_request/badges/development/coverage.svg)](https://gitlab.roqs.basf.net/WUZ35/moldflow_udb_request/pipelines)
<!-- badges: end -->
## Greetings from Happy Potter

Thanks for using h __app__ y potter to create this App. :zap:

Take a look at your brand new app in the _App Store_ here:

- [Development](https://app-dev.roqs.basf.net/moldflow_udb_request/)
- [QA](https://app-qa.roqs.basf.net/moldflow_udb_request/)
- [Production](https://app.roqs.basf.net/moldflow_udb_request/)

For pod information and logs of your App, try <a href="https://app.roqs.basf.net/portal/app/14671/logs" rel="noopener noreferrer" target="_blank"><img alt="Project Status Logs" aria-hidden="" class="project-badge" src="https://app.roqs.basf.net/appstore_portal_back_end/api/apps/14671/badges/logs"></a>

What happened to Kubecuddle?

[Kubecuddle Development](https://app-dev.roqs.basf.net/kubecuddle/v2/pod.html?deployment=moldflow-udb-request&namespace=moldflow-udb-request-dev), [Kubecuddle QA](https://app-qa.roqs.basf.net/kubecuddle/v2/pod.html?deployment=moldflow-udb-request&namespace=moldflow-udb-request-qual) and [Kubecuddle Production](https://app.roqs.basf.net/kubecuddle/v2/pod.html?deployment=moldflow-udb-request&namespace=moldflow-udb-request-prod) are still available, but usage is discouraged, as they are deprecated.

### Your current setup

* __Docker__: We have already containerized your app. It's ready to be deployed anywhere. You can have a look at the `Dockerfile`(s) in the different subfolders of your project for details on how this is done.

* __Kubernetes__: Your docker containers are aggregated into a pod and deployed together with a service connecting it to our API gateway. Optionally, you might also have a persistent volume claim for permanent storage. For more information on the configuration, have a look at the [`.appstore/deployment.yml`](https://gitlab.roqs.basf.net/WUZ35/moldflow_udb_request/-/blob/development/.appstore/deployment.yml).
* __CI/CD__: Remember the days you scratched your head on how and when to deploy? Those days are over! We already made sure your app gets automatically build and deployed the moment you make a change! Checkout the pipelines [here](https://gitlab.roqs.basf.net/WUZ35/moldflow_udb_request/pipelines?scope=branches).

#### GitLab Templates

We provide you with a set of [GitLab templates](https://docs.gitlab.com/ce/user/project/description_templates.html#overview) for creating pre-structured issues. They are located in the `.gitlab` folder of your repo.
### Vue container

Comes preinstalled with axios (HTTP request library) and stylus (CSS preprocessor).

JavaScript is linted using the [Standard JS](https://standardjs.com/) style.

#### Local development

You can find a standard Vue application in `frontend/vue/`. Paths of interest are `src/components/`, `src/views/`, `src/router.js`, `src/App.vue` and `src/main.js`.

To spin up locally follow these steps:

* `cd frontend/vue`
* `npm install` (you only need this once)
* `npm run serve`
* Your frontend is now available at [localhost:8080](http://localhost:8080).


