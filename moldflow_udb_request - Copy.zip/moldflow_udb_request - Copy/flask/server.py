# from flask import Flask, request, jsonify, make_response
from cgitb import text
from textwrap import wrap
from flask_cors import CORS
# import os
# import requests

from flask import Flask,request,jsonify, session, send_from_directory
# from flask_restful import Resource, Api
import sys
import os
import pathlib
import re

from flask_pymongo import PyMongo
from bson.objectid import ObjectId
import bson
from bson import json_util

import json
import requests
import datetime
from dotenv import load_dotenv
from requests_toolbelt.adapters.ssl import SSLAdapter
import ssl
# from werkzeug.utils import secure_filename
import uuid

from flask_caching import Cache

from email.message import EmailMessage
from smtplib import SMTP

adapter = SSLAdapter(ssl.PROTOCOL_TLSv1)
s = requests.Session()
s.mount('https://ultrasim.basf.net/', adapter)


# load .env variables
load_dotenv()

app = Flask(__name__, template_folder="./templates")
CORS(app, supports_credentials=True)

# implement flask_caching 
app.config.from_object('config.Config')
cache = Cache(app)
# clear cache according to env var
if os.getenv('CACHE_CLEAR') == 'true':
    cache.clear()

# api = Api(app)
PRODUCTION_ENV = False

if "APPSTORE_ENV" in os.environ:
    PRODUCTION_ENV = True

if PRODUCTION_ENV:
    # from myProxyFix import ReverseProxied
    # app.wsgi_app = ReverseProxied(app.wsgi_app)

    # ccsp mongodb
    mongodb_user = os.getenv('MONGODB_USER')
    mongodb_password = os.getenv('MONGODB_PASSWORD')
    mongodb_port = os.getenv('MONGODB_PORT')
    db_url = f"mongodb://{mongodb_user}:{mongodb_password}@dan.ccsp.basf.net:{mongodb_port}/mydb?authSource=admin"    
else: 
    # local mongodb
    db_url = 'mongodb://127.0.0.1:27017/local_mydb'

app.config["MONGO_URI"] = db_url
mongo = PyMongo(app).db

# file upload size limitation
app.config['MAX_CONTENT_LENGTH'] = 40 * 1000 * 1000

# session config
app.secret_key = os.getenv('SESSION_SECRET')

# ultrasim global variables
ultrasim_url="ultrasim.basf.net"
refresh_token_api_url="https://"+ultrasim_url+"/api/token/refresh/"
access_token = None
# proxies = {'https': 'http://10.4.55.31:8080/'}

# app store varibales
app_url = os.getenv('APP_URL')

ULTRASIM_API_BASE_URL = 'https://ultrasim.basf.net/api'

def getAccessToken():
    worker = os.getenv('WORKER')
    password = os.getenv('WORKER_PASSWORD')
    global access_token

    payload = {'username': worker, 'password': password}

    url = f'{ULTRASIM_API_BASE_URL}/token/'
    # url = 'https://ultrasim.basf.net/api/token/'
    # proxies = {'https': 'http://serverproxy.basf.net:8080'}

    res = requests.post(url, data=payload, verify=False)

    access_token = res.json()['access']
    print(f"access token res: {res.json()['access']}")
    return access_token


# getAccessToken()
# class SearchUdb(Resource):
#     def get(self,group_name):
#         #refresh token   
#         #refresh_obj = {"refresh":refresh_token}
#         #response = requests.post(refresh_token_api_url,json = refresh_obj,verify=False)
#         #response_data=response.json()
#         #access_token=response_data["access"]
#         #end:refresh token
#         # access_token = os.getenv("ULTRASIM_API_ACCESS_TOKEN")

#         my_headers = {"Authorization": "Bearer "+access_token}
#         grade_list=[]
#         page_no=1
#         goto_nextpage=True
#         while goto_nextpage==True:
#             if page_no>1:
                # mfdata_api_url="https://"+ultrasim_url+"/api/mfdata/?group="+group_name+"&page="+str(page_no)
#             else:
#                 mfdata_api_url="https://"+ultrasim_url+"/api/mfdata/?group="+group_name
#             try: 
#                 response = requests.get(mfdata_api_url, headers=my_headers,verify=False)
#                 response_data=response.json()
#                 response.raise_for_status()

#                 for results in response_data["results"]:
#                     grade_list.append(results["grade"])
#                 if response_data["next"] == None:
#                     goto_nextpage=False
#                 else:
#                     page_no=page_no+1
#             except requests.exceptions.HTTPError as he:
#                 print(he)
#                 return response_data
#         print(grade_list)
#         return {"grade":grade_list}

# api.add_resource(SearchUdb, '/search_udb/<string:group_name>')


def verify_access_token(func):
    def wrapper(*args, **kwargs):
        global access_token
        try:
            res = func(*args, **kwargs)
            if 'code' in res and res['code'] == 'token_not_valid':
                access_token = getAccessToken()
                return func(*args, **kwargs)
            else:
                return res
        except TypeError:
            return res

    return wrapper

@app.route("/mfdata", methods=['GET'])
# @cache.cached(timeout=259200)
def get_mfdata():
    mfdata = mongo.mfdata2.find()
    if not mfdata:
        return jsonify({'message': 'err'})

    filtered_mfdata = []
    def filter_with_Tsug_data(mf):
        if mf['TsugMelt'] and mf['TmaxMelt']:
            return True
    filtered_mfdata = list(filter(filter_with_Tsug_data, mfdata))

    def format_mf(raw_mf):
        mf = {
            # 'id': raw_mf['id'],
            # 'name': raw_mf['name'],
            'id': str(raw_mf['_id']),
            'name': raw_mf['name'],
        }
        return mf
    simple_mf = list(map(format_mf, filtered_mfdata))
    return jsonify({'message': 'ok', 'mfdata': simple_mf})

# @app.route("/material")
# @verify_access_token
# def hello():
#     res = requests.get('https://ultrasim.basf.net/api/material', \
#         headers={'Authorization': f'Bearer {access_token}'}).json()
#     # print(res)
#     return res

@app.route("/db")
def db():
    requests = mongo.udb_request.find()
    # return json.dumps([req for req in requests], default=str)
    return json_util.dumps([req for req in requests])
    # return jsonify([req for req in requests])

def get_email_addresses():
    email_address = ''
    if os.getenv('DEBUG_MODE') == 'true':
        dev_email = os.getenv('DEV_EMAIL_NOTI')
        if session['mail'] != dev_email and session['role'] == 'admin':
            email_address = dev_email + ';' + session['mail']
        else: 
            email_address = dev_email
    else:
        notify_admins = mongo.users.find({'role': 'admin'})
        for admin in [a for a in notify_admins]:
            email_address += admin['mail'] + ';'
        email_address = email_address[:-1]
    return email_address


def send_email_notification(subject, text, receiver='admin'):
    email_address = ''
    if receiver == 'admin':
        email_address = get_email_addresses()
    else:
        email_address = get_email_addresses() + ';' + receiver 

    body = {"to": email_address,
            "_from": "",
            "cc": "",
            "bcc": "",
            "reply_to": "",
            "subject": subject,
            "text": text
            }
    url = "https://app.roqs.basf.net/mail/api/mail?noreply=false"
    response = requests.post(url, json=body)
    return response

def send_email_for_rejection_noti(subject, text, receiver):
    body = {"to": receiver,
            "_from": "",
            "cc": "",
            "bcc": "",
            "reply_to": "",
            "subject": subject,
            "text": text
        }
    url = "https://app.roqs.basf.net/mail/api/mail?noreply=false"
    response = requests.post(url, json=body)
    return response

def send_email_with_files(subject, text, files):
    email_address = 'ultrasim_mat_data@basf.com'
    # email_address = get_email_addresses()

    data = {"to": email_address,
            "_from": "",
            "cc": "",
            "bcc": "",
            "reply_to": "",
            "subject": subject,
            "text": text,
            # "files": files
            }

    url = f"https://app.roqs.basf.net/mail/api/filesmail?noreply=false"
    response = requests.post(url, data=data, files=files)
    return response

def sendEmailExternal(recipient, sender, subject, text,cc=""):
    email = EmailMessage()
    email["Subject"] = subject
    email["From"] = sender
    email["To"] = recipient
    email["Cc"] = cc
    email.set_content(text,subtype='html')
    try:
        s = SMTP("mail.roqs.basf.net", "1587")
        s.send_message(email)
        s.quit()
    except Exception as e: 
        print(e)
        return e
    return "Send Email External Success"

# handle incoming request
@app.route("/add_requests", methods=['POST'])
def add_request():
    # res = sendEmailExternal('jeffrey.a.wu@basf.com', 'test_smtp', 'test smtp', 'test text')
    # return jsonify({'message':'success', 'res': res})

    def allowed_file(filename):
        ALLOWED_EXTENSIONS = {'pdf', 'png', 'jpg', 'jpeg', 'gif'}

        return '.' in filename and \
            filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

    u_id = str(uuid.uuid4())
    new_request = {
        'u_id': u_id,
        'client_email': request.form['client_email'],
        'udbs': json.loads(request.form['udbs']),
        'missing_udb': request.form['missing_udb'],
        'requester_username': session['username'],
        'requester_email': session['mail'],
        'submit_date': datetime.datetime.utcnow(),
        'files': [],
        'status': 'pending',
        'lock': False,
        'debug': True if os.getenv('DEBUG_MODE') == 'true' else False
    }

    upload_path = os.getenv('UPLOAD_PATH')
    pathlib.Path(upload_path, u_id).mkdir(exist_ok=True)

    for file in request.files.getlist('files'):
        if allowed_file(file.filename):
            filename = file.filename
            new_request['files'].append(filename)
            path = os.path.join(upload_path, u_id, filename)
            # abs_path = os.path.abspath(filename)
            # print('abs_path', abs_path)
            print('file saved path: ', path)
            file.save(path)

   
    if session['username'] is None:
        user = mongo.users.find_one_and_update({'mail': session['mail']}, \
        {'$push': {'requests': new_request}})
    else:
        user = mongo.users.find_one_and_update({'username': session['username']}, \
        {'$push': {'requests': new_request}})

    

    if user:
        subject = "You have a moldflow udb request to review"
        text = "You have a request to approve! Please check the system. "\
            f"Or click {app_url}/#/detailRequest/{new_request['u_id']} to proceed."
        
        send_email_notification(subject, text)
        return jsonify({'message':'success', 'highlight_id': new_request['u_id']})
    else: 
        return jsonify(message='failed')

@app.route("/requests", methods=['GET'])
def get_requests():
    re_requests = []
    if session['role'] == 'normal':
        found_user = mongo.users.find_one({'mail': session['mail']})
        if not found_user:
            return jsonify({'message':'noUserFound', 'requests': []})
        else:
            if 'requests' in found_user:
                re_requests = found_user['requests']
         
            return jsonify({'message':'ok', 'requests': re_requests})
    elif session['role'] == 'admin':
        users = mongo.users.find({})

        def test_req_filter(x):
            if 'debug' not in x or not x['debug']:
                return True

        for user in [u for u in users]:
            if 'requests' in user:
                if os.getenv('DEBUG_MODE') == 'true':
                    re_requests.extend(user['requests'])
                else:
                    re_requests.extend(list(filter(test_req_filter, user['requests'])))
        return jsonify({'message':'ok', 'requests': re_requests})

# get specific request
@app.route("/detail_request", methods=['POST'])
def get_detail_request():
    id = request.json['id']
    user = mongo.users.find_one({'requests.u_id':id})
    if user:
        d_request = [r for r in user['requests'] if r['u_id'] == id][0]
        return jsonify({'message':'ok', 'request': d_request})
    else: 
        return jsonify({'message':'err'})

# get uploaded file
@app.route('/files/<path:name>')
def send_file(name):
    path = os.getenv('SERVE_FILE_PATH')
    return send_from_directory(path, name)
    # return send_from_directory('files', name, as_attachment=True)

# get uploaded file
@app.route('/udb_file_requisition/<path:name>')
def send_requisition_template(name):
    return send_from_directory('misc', name)
    # return send_from_directory('files', name, as_attachment=True)

def download_udb_file(url):
    url = url.replace('cae-server.basf-china.com.cn', '10.139.166.13')
    res = requests.get(url)
    headers = res.headers
    if headers['content-type'] == 'application/octet-stream':
        filename = headers['content-disposition'].split('=')[-1].replace('%20', ' ')
        return ('files', (filename, res.content))

@app.route('/update_request_status', methods=['POST'])
def approve_request():
    id = request.form['id']
    status = request.form['status']
    upload_missing_udb = {'name': '', 'file': None}

    for file in request.files.getlist('files'):
        upload_missing_udb['name'] = file.filename
        upload_missing_udb['file'] = file
      
    # found_user = mongo.users.find_one_and_update({'requests.u_id':id}, \
    #     {'$set': {'requests.$.status': 'pending'}})
    # found_user = mongo.users.find_one_and_update({'requests.u_id':id}, \
    #     {'$set': {'requests.$.status': status}})

    found_user = mongo.users.find_one({'requests.u_id':id})
    
    def id_filter(x):
        if x['u_id'] == id:
            return True
    req = list(filter(id_filter, found_user['requests']))[0]
    
    if req['lock'] == True:
        return jsonify({'message':'locked', 'highlight_id': id})
    else:
        mongo.users.find_one_and_update({'requests.u_id':id}, \
            {'$set': {'requests.$.lock': True}})
        if status == 'approved':
            client_email = req['client_email']
            if upload_missing_udb['name']:
                udbs = [{'name': upload_missing_udb['name'][:-4]}]
                files = [('files', (upload_missing_udb['name'], upload_missing_udb['file']))]
                send_udb_to_client(udbs, files, client_email, req['requester_email'])
            else:
                udbs = req['udbs']
                udb_details = []

                for udb in udbs:
                    detail = get_udb_detail(udb['id'])
                    # change the dateModified of udb to today's date 
                    detail['dateModified'] = datetime.datetime.now().replace(microsecond=0).isoformat() + 'Z'
                    del detail['_id']
                    udb_details.append(detail)
                
                request_detail = {
                    'id': id,
                    'udb_details': udb_details,
                }
                try:
                    # res = requests.post('http://10.139.166.10/api/get_udb', json=request_detail).json()
                    res = requests.post(f"http://10.139.166.13/api/get_udb", json=request_detail).json()
                    # res = requests.post(f"http://{os.getenv('CAE_SERVER_DOMAIN')}/api/get_udb", json=request_detail).json()
                except Exception as e:
                    mongo.users.find_one_and_update({'requests.u_id':id}, \
                        {'$set': {'requests.$.status': 'pending', 'requests.$.lock': False}})
                    return jsonify({'message':'err', 'err_detail': f'{e}'})
                print('res', res)

                # def download_udb_file(url):
                #     res = requests.get(url)
                #     headers = res.headers
                #     if headers['content-type'] == 'application/octet-stream':
                #         filename = headers['content-disposition'].split('=')[-1].replace('%20', ' ')
                #         return ('files', (filename, res.content))

                files = []

                if res['status'] == 'ok':
                    for url in res['urls']:
                        files.append(download_udb_file(url))

                send_udb_to_client(udbs, files, client_email, req['requester_email'])
        if status == 'denied':
            udbs_text = ''
            for udb in req['udbs']:
                udbs_text = udb['name'] + ';'
                udbs_text = udbs_text[:-1]
            subject = f'Your request for udb file: {udbs_text} has been denied.'
            text = request.form['RejectComment']
            receiver = req['requester_email']
            send_email_for_rejection_noti(subject, text, receiver)

        found_user = mongo.users.find_one_and_update({'requests.u_id':id}, \
            {'$set': {
                'requests.$.status': status, 
                'requests.$.reviewer': session['mail'],
                'requests.$.review_date': datetime.datetime.utcnow(),
            }})
        if found_user:
            return jsonify({'message':'success', 'highlight_id': id})
        else: 
            return jsonify({'message':'err'})

def get_udb_detail(id):
    raw_mf = mongo.mfdata2.find_one({'_id': ObjectId(id)})
    return raw_mf

def send_udb_to_client(udbs, files, client_email, noti_receiver):
    subject = 'Moldflow udb files attached'
    text = 'Please refer to the attachments.' + ' ' + client_email
                    
    email_api_res = send_email_with_files(subject, text, files)
    if email_api_res.status_code == 200:
        # send noti to admins that the udbs have been sent
        subject = 'The udb(s) has been sent to the client'
        files_name = ''
        for udb in udbs:
            files_name = files_name + udb['name'] + '.udb' + ', '
        text = f'The {files_name[:-2]} has/have been sent to {client_email}'
        send_email_notification(subject, text, noti_receiver)

@app.route("/resend_udbs", methods=['POST'])
def resend_udbs():
    req = request.json['request']

    req_id = req['u_id']
    udbs = req['udbs']
    client_email = req['client_email']
    noti_rec = req['requester_email']
    files = []

    # generate urls for downloading udbs
    for udb in udbs:
        udb_d = get_udb_detail(udb['id'])
        name = f"{udb_d['group']}_{udb_d['grade']}_{udb_d['family']}".replace('/', ' ')
        url = f"http://{os.getenv('CAE_SERVER_DOMAIN')}/requests/{req_id}/{name}.udb"
        files.append(download_udb_file(url)) 

    try: 
        send_udb_to_client(udbs, files, client_email, noti_rec)
        return jsonify({'message':'success'})
    except Exception as e:
        return jsonify({'message':f'failed. Except: {e}'})
        



@app.route("/login", methods=['POST'])
def login():
    mail = request.json['mail']
    username = request.json['username']
    full_name = request.json['full_name']

    found_user = mongo.users.find_one({'mail': mail})

    # Not authorized or active
    if not found_user:
        return jsonify(message='Not authorized!')
    elif found_user: 
        if not found_user['active']:
            return jsonify(message='Not authorized!')
        else:
            # update new user info
            if not found_user['username']:
                mongo.users.update_one({'mail': mail}, \
                    {'$set': {'username': username, 'full_name': full_name, \
                        'last_login': datetime.datetime.utcnow()}})

    # record user last login time
    mongo.users.update_one({'mail': mail}, \
        {'$set': {'last_login': datetime.datetime.utcnow()}})

    session['username'] = found_user['username']
    session['full_name'] = found_user['full_name']
    session['mail'] = found_user['mail']
    session['role'] = found_user['role']

    msg = f"Logged in. Session saved. Email: {session['mail']}. " \
        f"username: {session['username']}. role: {session['role']}"
    print(msg)
    return jsonify({'message':msg, 'role': session['role'], 'debug_mode': os.getenv('DEBUG_MODE')})

@app.route("/apply_for_account", methods=['POST'])
def apply_for_account():
    # mail = request.json['user_info'].mail
    # full_name = request.json['user_info'].full_name
    user_info = request.json['user_info']
    subject = 'A new user has applied for the access to the Moldflow udb Request'
    text = f"The user's username is {user_info['full_name']}." \
        f"The email address is {user_info['mail']} ." \
            f"Click {app_url}/#/createAccount/{user_info['mail']} to creat an account for the user."
    send_email_notification(subject, text)
    return jsonify({'message': 'ok'})
    # print('mail', mail)
    
@app.route("/create_account", methods=['POST'])
def create_account():
    mail = request.json['email']
    if session['role'] == 'admin': 
        res = add_new_user(mail, 'normal')
        if res:
            return jsonify({'message': 'ok'})
        else:
            return jsonify({'message': 'error'})
    else:
        return jsonify({'message': 'error'})

def add_new_user( mail, role, username=None, full_name=None, active=True) :
    found_user = mongo.users.find_one({'mail': mail})
    if found_user:
        print('The user is already existed.')
        return 'Already existed'
    else:
        try:    
            mongo.users.insert_one({
                'username': username,  
                'full_name': full_name,
                'mail': mail,
                'role': role,
                'active': active
            })
            return True
        except Exception as e:
            print('mongo.users.insert_one Exception: ', e)
            return False

    
        


# @app.route("/material")
# def hello():

#     # access_token = os.getenv("ULTRASIM_API_ACCESS_TOKEN")
#     global access_token

#     res = requests.get('https://ultrasim.basf.net/api/material', headers={'Authorization': f'Bearer {access_token}'}).json()
#     if 'code' in res and res['code'] == 'token_not_valid':
#         access_token = getAccessToken()
#         return hello()
#     else:
#         print(res)
#         return res

# @app.route("/material")
# def hello():

#     access_token = os.getenv("ULTRASIM_API_ACCESS_TOKEN")

#     res = requests.get('https://ultrasim.basf.net/api/material', headers={'Authorization': f'Bearer {access_token}'}).json()
#     print(res)
#     return res

@app.route('/test_10', methods=['GET'])
def test():
    res = requests.get('http://10.139.166.10/api')
    return res.text


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0")