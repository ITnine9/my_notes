import os
from flask_pymongo import PyMongo
from dotenv import load_dotenv
from pymongo import MongoClient
from colorama import init, Fore
import requests

# init colorama for terminal
init(autoreset=True)

# load .env variables
load_dotenv()

print('-' * 60)
print(f'{Fore.CYAN}Welcome to Moldflow udb Request shell.')
print('-' * 60)

def let_user_pick(options):
    print("Please choose your env:")

    for idx, element in enumerate(options):
        print("{}) {}".format(idx + 1, element))

    i = input("Enter number: ")
    try:
        if 0 < int(i) <= len(options):
            return int(i) - 1
    except:
        pass
    return None

opts = ['production', 'development']
idx = let_user_pick(opts)
env = opts[idx]

# global vars
access_token = None
ULTRASIM_API_BASE_URL = 'https://ultrasim.basf.net/api'

def getAccessToken():
    worker = os.getenv('WORKER')
    password = os.getenv('WORKER_PASSWORD')
    global access_token

    payload = {'username': worker, 'password': password}

    url = f'{ULTRASIM_API_BASE_URL}/token/'
    # url = 'https://ultrasim.basf.net/api/token/'
    proxies = {'https': 'http://serverproxy.basf.net:8080'}

    res = requests.post(url, data=payload, verify=False, proxies=proxies)

    access_token = res.json()['access']
    print(f"access token res: {res.json()['access']}")
    return access_token
    
def verify_access_token(func):
    def wrapper(*args, **kwargs):
        global access_token
        try:
            res = func(*args, **kwargs)
            if 'code' in res and res['code'] == 'token_not_valid':
                access_token = getAccessToken()
                return func(*args, **kwargs)
            else:
                return res
        except TypeError:
            return res

    return wrapper

# def get_udbfiles():
#     url = f'{ULTRASIM_API_BASE_URL}/udbfiles/'

#     @verify_access_token
#     def call_udbfiles_api(url):
#         res = requests.get(url, \
#             headers={'Authorization': f'Bearer {access_token}'}).json()
#         return res

#     while url:
#         res = call_udbfiles_api(url)
#         for udb in res['results']:
#             mongo.udbfiles.insert_one({
#                 'name': udb['name'],
#                 'udbFile': udb['udbFile'],
#                 'mfdata_id': udb['mfdata'].split('/')[-2],
#                 'desc': udb['description'],
#                 'encrypted': udb['encrypted']
#             })

#         url = res['next']
        
#     return True

if env == 'production':
    # ccsp mongodb
    mongodb_user = os.getenv('MONGODB_USER')
    mongodb_password = os.getenv('MONGODB_PASSWORD')
    mongodb_port = os.getenv('MONGODB_PORT')
    db_uri = f"mongodb://{mongodb_user}:{mongodb_password}"\
        f"@dan.ccsp.basf.net:{mongodb_port}/mydb?authSource=admin"
    client = MongoClient(db_uri)
    mongo = client.mydb

    print(f'{Fore.RED}You are in the {env.upper()} env. Proceed with caution!')
else: 
    # local mongodb
    print(f'{Fore.GREEN}You are in the {env.upper()} env.')
    db_uri = 'mongodb://127.0.0.1:27017/local_mydb'
    client = MongoClient(db_uri)
    mongo = client.local_mydb

def add_new_user( mail, role, username=None, full_name=None, active=True):
    found_user = mongo.users.find_one({'mail': mail})
    if found_user:
        print('The user is already existed.')
    else:
        mongo.users.insert_one({
            'username': username,  
            'full_name': full_name,
            'mail': mail,
            'role': role,
            'active': active
        })
        return True

def disable_user_account(mail):
    found_user = mongo.users.find_one({'mail': mail})
    if not found_user:
        print('The user account does not exist!')
        return False
    else:
        inp = input(f"Are you sure you want to disable user account: \
            {found_user['mail']}, role: {found_user['role']}. \
                Type 'yes' to proceed.")
        if inp.lower() == 'yes':
            mongo.users.find_one_and_update({'mail': mail}, {'active': False})
        else: 
            return False

@verify_access_token
def download_mfdata():
    def format_mf(raw_mf):
        raw_mf['name'] = f"{raw_mf['group']} {raw_mf['grade']} {raw_mf['family']}"
        return raw_mf
    try:
        url = f'{ULTRASIM_API_BASE_URL}/mfdata/'
        while url:
            res = requests.get(url, \
                headers={'Authorization': f'Bearer {access_token}'}).json()
            if 'code' in res and res['code'] == 'token_not_valid':
                return res
            next = res['next']
            raw_mfs = res['results']
            for raw in raw_mfs:               
                if raw['specificHeatT'] is not None and raw['specificHeatCp'] is not None:
                    mongo.mfdata.insert_one(format_mf(raw))
            url = next
        print('All mf_data have been downloaded successfully!')
    except Exception as e:
        print('download_mfdata err: ', e)

def filterOutRangeMeltData():
    mfdata = mongo.mfdata.find()
    
    def filter_melt(mf):
        if mf['TsugMelt'] is not None and mf['TmaxMelt'] is not None:
            if mf['TsugMelt'] > mf['TmaxMelt']:
                return True

    def only_id(mf):
        return (mf['id'], mf['grade'])
    
    filtered_mf = list(filter(filter_melt, mfdata))
    invalid_mf = list(map(only_id, filtered_mf))

    for item in enumerate(invalid_mf):
        print(item, '\n')
    # return invalid_mf, len(invalid_mf)

def get_invalid_mfdata():
    mfdata = mongo.mfdata.find()

    def filter_with_Tsug_data(mf):
        if not mf['TsugMelt'] or not mf['TmaxMelt']:
            return True

    filtered_mf = list(filter(filter_with_Tsug_data, mfdata))
    for i, a in enumerate(filtered_mf):
        print(a['id'])
    
    return len(filtered_mf)

