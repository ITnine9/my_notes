<template>
  <v-app>
    <v-overlay 
      z-index="15"
      color="white"
      opacity="0.9"
      :value="$store.state.page_loader_toggle"
    >
      <v-progress-circular
        indeterminate
        size="64"
        color="primary"
      ></v-progress-circular>
    </v-overlay>
    
    <v-dialog
      v-model="dialogToggle"
      persistent
      max-width="290"
    >
    <!-- <template v-slot:activator="{ on, attrs }">
      <v-btn
        color="primary"
        dark
        v-bind="attrs"
        v-on="on"
      >
        Open Dialog
      </v-btn>
    </template> -->
    <v-card v-if="applyToggle">
      <v-card-title class="text-h5">
        Account not created
      </v-card-title>
      <v-card-text>Your account has not been created. Please click the following button to apply.</v-card-text>
      <v-card-actions>
        <v-spacer></v-spacer>
        
        <v-btn
          color="green darken-1"
          text
          @click="applyForAccount"
        >
          Apply
        </v-btn>
      </v-card-actions>
    </v-card>
    <v-card v-if="appliedToggle">
      <v-card-title class="text-h5">
        Account applied
      </v-card-title>
      <v-card-text>Application for a new account has been made. Please wait for the admin to review.</v-card-text>
    </v-card>
    </v-dialog>
    <v-navigation-drawer
        app
        permanent
        width="180"
        dark
        src="https://cdn.vuetifyjs.com/images/backgrounds/bg-2.jpg"
      >

      <v-img
        alt="BASF Logo"
        class=""
        contain
        src="https://app.roqs.basf.net/style/images/logo.svg"
        transition="scale-transition"
        max-height="56"
      />
      <v-divider></v-divider>
      <v-list
        dense
        nav
      > 
        
        <v-list-item
          link
          to="/"
        >
          <!-- <v-list-item-icon>
            <v-icon>{{ item.icon }}</v-icon>
          </v-list-item-icon> -->

          <v-list-item-content>
            <v-list-item-title>New Request</v-list-item-title>
          </v-list-item-content>
        </v-list-item>
        <v-list-item
          link
          to="/pendingRequest"

        >
          <!-- <v-list-item-icon>
            <v-icon>{{ item.icon }}</v-icon>
          </v-list-item-icon> -->

          <v-list-item-content>
            <v-list-item-title>My Pending Request</v-list-item-title>
          </v-list-item-content>
        </v-list-item>
        <v-list-item
          link
          to="/about"
        >
          <!-- <v-list-item-icon>
            <v-icon>{{ item.icon }}</v-icon>
          </v-list-item-icon> -->

          <v-list-item-content>
            <v-list-item-title>About</v-list-item-title>
          </v-list-item-content>
        </v-list-item>
      </v-list>
    </v-navigation-drawer>
    
    <v-app-bar
      app
      color="primary"
      dark
      height="56"
    >
    

      <v-toolbar-title>Moldflow udb Request <span v-if="debug_mode">(debug_mode)</span></v-toolbar-title>
      <v-spacer></v-spacer>
      <v-icon class="mdi mdi-account"></v-icon><span class="ml-1">{{ $store.state.user.full_name }}</span>

    </v-app-bar>

    <v-main>
        <v-alert
          border="left"
          color="blue"
          dismissible
          icon="mdi-human-greeting"
          type="success"
          dense
          transition="scroll-y-transition"
          class="mb-0"
          outlined
          v-if="user"
        >Welcome to the system, {{ user }}</v-alert>
        <v-alert type="error" v-if="errorPageToggle" dense>
          Something went wrong. Please try again or contact system administrator.
        </v-alert>
        <v-alert type="warning" v-if="warningAlertToggle" dense>
          This request has been processing by another admin! 
          The web page will refresh in 5 seconds.
        </v-alert>
      <router-view></router-view>
      
    </v-main>
  </v-app>
</template>

<script>
import { mapMutations } from 'vuex'
import BasfAuth from 'basf-auth';

export default {
  name: 'App',
  data: () => ({
    
  }),
  async created() {
    if (process.env.NODE_ENV === 'production') {
      // proceed to basf federation service api
      await this.startAuthenticationProcess();
    } else {

      const local_dev = 'wuz35';
      // const local_dev = 'JinJi';
      await this.getMoreUserInfo(local_dev);
    }
  },
  computed: {
    user() {
      return this.$store.state.user.full_name;
    },
    errorPageToggle() {
      return this.$store.state.errorAlertToggle;
    },
    warningAlertToggle() {
      return this.$store.state.warningAlertToggle;
    },
    user_info() {
      return this.$store.state.user;
    },
  },
  data() {
    return {
      debug_mode: false,
      dialogToggle: false,
      appliedToggle: false,
      applyToggle: true
    }
  },
  methods: {
    ...mapMutations([
      'updateUserInfo',
      'turnOnLoader',
      'turnOffLoader',
      'updateHightlightId'
    ]),
    async startAuthenticationProcess() {
      let loggedInUser = null;
      let username = '';
      // checks if currently authenticated
      this.turnOnLoader();

      const isAuthenticated = await BasfAuth.isAuthenticated();
      
      if (isAuthenticated) {
        // Do something when authenticated

        loggedInUser = BasfAuth.username;
        username = BasfAuth.username;
        console.log('Already logged in!');
      } else {
        try {
          // If not authenticated, start authentication process
          BasfAuth.authenticate();
          username = BasfAuth.username;
          console.log('username: ', username);
        } catch (e) {
          console.log('BasfAuth.authenticate() error!');
          // process error
        } finally {
          console.log('BasfAuth: ', BasfAuth);
        }
      }
      await this.getMoreUserInfo(username);
    },
    async getMoreUserInfo(username) {
      try {
        const res = await this.$axios.get('/users', { 
          baseURL: 'https://app.roqs.basf.net/ldap/api/v2',
          params: {
            username: username,
            type: 'employee',
            active: true,
            page: 1,
            per_page: 20
          }
        });
        // const { full_name, mail } = res.data[0];
        const full_name = res.data[0].full_name;
        const mail = res.data[0].mail.toLowerCase();
        let role = '';

        // backend auth process
        const login_result = await this.$axios.post('/moldflow_udb_request/api/login', { username, full_name, mail });

        console.log('users api res: ', res.data[0]);
        this.debug_mode = login_result.data.debug_mode == 'true' ? true : false;
        console.log('%c' + login_result.data.message, 'color: blue; font-size:20px');
        role = login_result.data.role;
        // console.log('Logged in to the system successfully.');
        
        this.updateUserInfo({ username, full_name, mail, role });
        if (login_result.data.message === 'Not authorized!') {
          this.dialogToggle = true;
        }

        this.turnOffLoader();
      } catch(e) {
        console.log('users api err: ', e);
        console.log('Failed to logged in to the system ');
      }          
    },
    async applyForAccount() {
      this.applyToggle = false;
      const res = await this.$axios.post('/moldflow_udb_request/api/apply_for_account', {
        user_info: this.user_info
      })

      this.appliedToggle = true;
    }
  }
}
</script>
<style scoped>

</style>
