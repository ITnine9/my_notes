<template>
    <v-file-input
        show-size
        counter
        multiple
        label="File input"
    ></v-file-input>
</template>
<script>
export default {
    name: 'FileUpload',
    data() {
        return {

        }
    },
    

}
</script>
