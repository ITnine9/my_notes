<template>
<v-card
    tile
  >
    <v-list>
        <v-subheader>Top {{ results.length }} search matches - Click to Select</v-subheader>
        <v-list-item v-ripple v-for="item in results" :key="item.obj.id" class="search-item" @click="$emit('addUdb', item.obj)">
            <v-list-item-content class="d-flex flex-row">
                <v-list-item-title v-html="highlightedResult(item)"></v-list-item-title>
                <!-- <v-icon class="mr-1 icon-position" v-if="item.obj.has_udbfile">mdi-file-document-outline</v-icon> -->
            </v-list-item-content>
        </v-list-item>
    </v-list>
    
</v-card>
</template>
<script>
import fuzzysort from 'fuzzysort'
export default {
    name: 'SearchResultList',
    props: ['results'],
    data() {
        return {

        }
    },
    methods: {
        highlightedResult(item) {
            return fuzzysort.highlight(item, '<b>', '</b>');
        }
    },
}

</script>
<style scoped>
.search-item {
    cursor: pointer;
}

.search-item:hover {
    background: rgb(237, 237, 237);
}

.icon-position {
    position: absolute;
    right: 5px;
}
</style>
