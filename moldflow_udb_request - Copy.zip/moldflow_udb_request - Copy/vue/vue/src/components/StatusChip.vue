<template>
    <div>
        <v-chip 
          color="yellow accent-2" 
            v-if="status === 'pending'"
          >
          <v-icon class="mr-1">mdi-timer-sand</v-icon>Pending
          <!-- <v-icon class="mdi mdi-timer-sand mr-1" ></v-icon>Pending -->
        </v-chip>

        <v-chip 
          color="green accent-4" 
          v-if="status === 'approved'"
          >
          <v-icon class="mr-1">mdi-check-circle-outline</v-icon>Approved 
          <!-- <v-icon class="mdi mdi-check-circle-outline mr-1" ></v-icon>Approved  -->
        </v-chip>

        <v-chip 
          color="red" 
          v-if="status === 'denied'"
          >
          <v-icon class="mr-1">mdi-close-circle-outline</v-icon>Denied 
          <!-- <v-icon class="mdi mdi-close-circle-outline mr-1" ></v-icon>Denied  -->
        </v-chip>
    </div>
    
</template>
<script>
export default {
    name: 'StatusChip',
    props: ['status']
}
</script>