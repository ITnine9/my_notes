<template>
<v-card
    tile
  >
    <v-list>
        <v-subheader>udb selected</v-subheader>
        <v-list-item v-for="item in list" :key="item.id">
            <v-list-item-content class="d-flex flex-row selected-content">
                <v-list-item-title>{{ item.name }}</v-list-item-title>
            </v-list-item-content>

            <v-list-item-icon>
                <v-icon class="mdi mdi-close-circle d-block" @click="delItem(item.id)"></v-icon>
            </v-list-item-icon>
        </v-list-item>
        <p v-if="warningToggle" class="validation-warning v-messages__message">Please select at least one udb file.</p>
    </v-list>
    
</v-card>
</template>
<script>
export default {
    name: 'selectedList',
    props: ['list', 'validate'],
    data() {
        return {

        }
    },
    methods: {
        delItem(id) {
            this.$emit('delItem', id);
        }
    },
    computed: {
        warningToggle() {
            return this.validate && this.list.length === 0;
        }
    }
}

</script>
<style scoped>
    .selected-content {
        background: lavender;
    }

    .validation-warning {
        text-align: left;
        color: #ff5252;
        font-size: 12px;
        padding-left: 16px;

    }
</style>
