import Vue from 'vue'
import Router from 'vue-router'
import Home from './views/Home.vue'
import NewRequest from './views/NewRequest.vue'
import PendingRequest from './views/PendingRequest.vue'
import DetailRequest from './views/DetailRequest.vue'
import PageNotfound from './views/404.vue'
import CreateAccount from './views/CreateAccount'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'newRequest',
      component: NewRequest
    },
    {
      path: '/pendingRequest',
      name: 'pendingRequest',
      component: PendingRequest
    },
    {
      path: '/detailRequest/:id',
      name: 'detailRequest',
      component: DetailRequest
    },
    {
      path: '/createAccount/:email',
      name: 'createAccount',
      component: CreateAccount
    },
    {
      path: '*',
      name: 'pageNotfound',
      component: PageNotfound
    },
    {
      path: '/about',
      name: 'about',
      // route level code-splitting
      // this generates a separate chunk (about.[hash].js) for this route
      // which is lazy-loaded when the route is visited.
      component: () => import(/* webpackChunkName: "about" */ './views/About.vue')
    }
  ]
})