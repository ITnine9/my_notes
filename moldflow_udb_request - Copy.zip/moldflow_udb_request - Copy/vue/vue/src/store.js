import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    user: {
      username: '',
      full_name: '',
      mail: '',
      role:'',
    },
    page_loader_toggle: false,
    highlight_id: '',
    errorAlertToggle: false,
    warningAlertToggle: false
  },
  mutations: {
    updateUserInfo(state, userInfo) {
      state.user.full_name = userInfo.full_name;
      state.user.username = userInfo.username;
      state.user.mail = userInfo.mail;
      state.user.role = userInfo.role;
    },
    turnOnLoader(state) {
      state.page_loader_toggle = true;
    },
    turnOffLoader(state) {
      state.page_loader_toggle = false;
    },
    updateHightlightId(state, id) {
      state.highlight_id = id;
    },
    turnOnErrorAlert(state) {
      state.errorAlertToggle = true;
    },
    turnOffErrorAlert(state) {
      state.errorAlertToggle = false;
    },
    turnOnWarningAlert(state) {
      state.warningAlertToggle = true;
    },
    turnOffWarningAlert(state) {
      state.warningAlertToggle = false;
    }
  },
  actions: {

  }
})
