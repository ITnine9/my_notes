<template>
    <v-container>
        <div id='error'>
            <h2>Page Not Found</h2>
            <h1>404</h1>
        </div>
    </v-container>
</template>
<script>

export default {
    name: 'pageNotFound'
}
</script>
<style scoped>
    #error {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        text-align: center;
        /* border: 1px solid black; */
        /* width: 100%;
        height: 100%; */
    }
</style>
