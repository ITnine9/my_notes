<template>
  <div class="about">
    <div class="description">
      <h1>The online <span class="highlighted-text">Moldflow udb Delivery</span> Platform</h1>
      <P class="des-p">A user-friendly, approachable and automated system for the delivery of udb files.</P>
      <p class="des-p">Developed by the CAE team China</p>
    </div>
    <h3 class="video-des">How to fill the udb request form </h3>
    <video class="video-tip" controls muted>
      <source src="../assets/submit_request.webm"
        type="video/webm" />
      <p>
        Your browser doesn't support HTML video. Here is a
        <a href="../assets/submit_request.webm">link to the video</a> instead.
      </p>
    </video>

    <p class="des-mail">If you want to contact the development team, please write us an email: 
      <a href="mailto:ultrasim_mat_data@basf.com">ultrasim_mat_data@basf.com</a>

    </p>
  </div>
</template>
<style scoped>
  .about {
    max-width: 900px;
    margin: 10px auto;
    text-align: center;
  }

  .description {
    margin: 30px 0;
  }

  .des-p {
    margin: 0;
  }


  .video-tip {
    margin: 10px 0;
    max-width: 900px;
  }

  .highlighted-text {
    background: -webkit-linear-gradient(315deg,#42d392 25%,#647eff);
    background-clip: text;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
  }

  .des-mail {
    font-size: 14px;
  }
</style>