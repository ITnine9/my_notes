<template>
    <v-container>
        <div id='error'>
            <h3> {{ msg }} </h3>
        </div>
    </v-container>
</template>
<script>

export default {
    name: 'createAccount',
    data() {
        return {
            msg: ''
        }
    },
    mounted() {
        this.create_accunt();
    },
    methods: {
        async create_accunt() {
            const res = await this.$axios.post('/moldflow_udb_request/api/create_account', {
                email: this.$route.params.email
            })

            if (res.data.message === 'ok') {
                this.msg = "The account has been created successfully."
            } else if (res.data.message === 'Already existed') {
                this.msg = "There is already existing account."
            } else {
                // error happened
            }
        }
    }
}
</script>
<style scoped>
    #error {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        text-align: center;
        /* border: 1px solid black; */
        /* width: 100%;
        height: 100%; */
    }
</style>
