<template>
    <div>
        <v-alert type="success" v-if="successAlertToggle" dense>
            The udb(s) has been resent to the client.
        </v-alert>
        <v-container class="px-16 compacted">
            <v-card :loading="loading_toggle">
                <template slot="progress">
                    <v-progress-linear color="blue lighten-3" indeterminate></v-progress-linear>
                </template>
                <v-overlay 
                    z-index="15"
                    color="white"
                    opacity="1"
                    :value="overlay_loading"
                    :absolute="true"
                >
                <v-progress-circular
                    indeterminate
                    size="64"
                    color="primary"
                ></v-progress-circular>
                </v-overlay>
                <div class="py-8" >
                    <v-row>
                        <v-col class="row-label">
                            Status:
                        </v-col>
                        <v-col>
                            <StatusChip :status=" request.status "></StatusChip>
                        </v-col>
                    </v-row>
                    <v-row>
                        <v-col class="row-label">
                            Submission Date:
                        </v-col>
                        <v-col>
                            {{ format_date(request.submit_date) }}
                        </v-col>
                    </v-row>
                    <v-row>
                        <v-col class="row-label">
                            Applicant Email:
                        </v-col>
                        <v-col>
                            {{ request.requester_email }}
                        </v-col>
                    </v-row>
                    <v-row>
                        <v-col class="row-label">
                            udbs:
                        </v-col>
                        <v-col>
                            <span v-for="(udb, index) in request.udbs" :key="udb.id"> {{ udb.name }} 
                                <v-icon class="mdi mdi-file-question" v-if="request.missing_udb"></v-icon>
                                <span v-if="index !== request.udbs.length - 1">, </span>
                            </span>
                        </v-col>
                    </v-row>
                    <v-row v-if="request.missing_udb && !request.lock && role === 'admin'">
                        <v-col class="row-label row-label-upload">
                            Upload missing Udb:
                        </v-col>
                        <v-col class="row-label row-label-upload">
                            <v-file-input multiple class="mt-0 pt-0 missing_udb_upload" label="File input" v-model="upload_missing_udbs"
                            chips ></v-file-input>
                        </v-col>
                    </v-row>
                    <v-row>
                        <v-col class="row-label">
                            Client Email:
                        </v-col>
                        <v-col>
                            {{ request.client_email }}
                        </v-col>
                    </v-row>

                    <v-row>
                        <v-col class="row-label">
                            file(s):
                        </v-col>
                        <v-col>
                            <span v-for="(file, idx) in request.files" :key="file">
                                <br v-if="idx > 0">
                                <!-- {{ file }} -->
                                <a :href="file_url(file)" target="_blank">{{ file }}</a>
                                
                            </span>
                            <span v-if="request.files && request.files.length === 0">
                                /
                            </span>
                        </v-col>
                    </v-row>
                    <v-row>
                    <v-dialog
                        v-model="dialogRejectDisplay"
                        persistent
                        max-width="650"
                        >
                        <v-card>
                            <v-card-title>
                                <span class="text-h5">Comments for rejection</span>
                            </v-card-title>
                            <v-card-text>
                                Please input comments:
                                <v-textarea v-model="rejectComment"
                                    class="mt-0"
                                    prepend-icon="mdi-comment-remove-outline" 
                                    required
                                    rows="4"></v-textarea>
                            </v-card-text>
                            <v-card-actions>
                                <v-btn
                                    color="blue darken-1"
                                    text
                                    @click="dialogRejectDisplay = false"
                                >
                                    Close
                                </v-btn>
                                <v-btn
                                    color="blue darken-1"
                                    text
                                    @click="proceedRejection"
                                >
                                    Proceed
                                </v-btn>
                            </v-card-actions>
                        </v-card>
                    </v-dialog>
                    </v-row>
                    <v-row align="center" v-if="!request.lock && role === 'admin'">
                        <v-col class="row-label">
                            <v-btn color="error" @click="dialogRejectDisplay = true">
                                Reject
                            </v-btn>
                        </v-col>
                        <v-col>
                            <v-btn color="success" @click="approveRequest">
                                Approve
                            </v-btn>
                        </v-col>
                    </v-row>
                    <!-- resend button -->
                    <v-row v-if="role === 'admin' && request.status === 'approved' && !request.missing_udb">
                        <v-col class="row-label-center">
                            <v-btn color="orange" :disabled="resend_btn_disabled" @click="resendUdbs">
                                Resend
                            </v-btn>
                        </v-col>
                    </v-row>
                </div>
            </v-card>
        </v-container>
    </div>
</template>

<script>
    import StatusChip from "../components/StatusChip";
    import {
        mapMutations
    } from 'vuex';

    import utiliyMixin from "../mixins/mixin"



    export default {
        name: "DetailRequest",
        components: {
            StatusChip
        },
        mixins: [utiliyMixin],
        data() {
            return {
                id: '',
                request: {},
                loading_toggle: true,
                overlay_loading: true,
                resend_btn_disabled: false,
                successAlertToggle: false,
                upload_missing_udbs: [],
                dialogRejectDisplay: false,
                rejectComment: 'The UDB file is currently unavailable for these grades. However, we can assist you in generating the UDB file with the related tests, but please note that this service may cost around 5000-6000 USD. Additionally, please prepare at least 15kg of sample materials and cover the associated costs.',
            }
        },
        computed: {
            role() {
                return this.$store.state.user.role;
            }
        },
        created() {
            this.id = this.$route.params.id;
            this.getRequestDetail(this.id);
        },
        beforeRouteLeave(to, from, next) {
            this.turnOffErrorAlert();
            this.turnOffWarningAlert();
            next();
        },
        methods: {
            ...mapMutations([
                'turnOnLoader',
                'turnOffLoader',
                'updateHightlightId',
                'turnOnErrorAlert',
                'turnOffErrorAlert',
                'turnOnWarningAlert',
                'turnOffWarningAlert'
            ]),
            proceedRejection() {
                this.dialogRejectDisplay = false;
                this.rejectRequest();
            },
            resendUdbs() {
                this.turnOnLoader();
                this.$axios.post('/moldflow_udb_request/api/resend_udbs', {
                    request: this.request
                }).then(res => {
                        let msg = res.data.message;
                        if (msg === 'success') {
                            console.log('resend_udbs api call success');
                            this.successAlertToggle = true;
                            this.resend_btn_disabled = true;
                        } else {
                            console.log(`resend_udbs api call ${msg}.`);
                            this.turnOnErrorAlert();
                        }
                    })
                    .catch(err => {
                        console.log(`resend_udbs api call error ${err}!`);
                        this.turnOnErrorAlert()
                    })
                    .finally(() => {
                        this.turnOffLoader();
                    })
            },
            file_url(file) {
                // to disable the URI fragment
                let fileName = file.replaceAll('#', '%23');
                return '/moldflow_udb_request/api/files/' + this.id + '/' + fileName;
            },
            format_date(str) {
                return new Date(str).toLocaleString();
            },
            getRequestDetail(id) {
                this.$axios.post('/moldflow_udb_request/api/detail_request', {
                    id
                }).then(res => {
                    console.log('/moldflow_udb_request/api/detail_request res: ', res);
                    if (res.data.message === 'ok') {
                        this.request = this.addMissingUdb(res.data.request);

                        this.loading_toggle = false;
                        this.overlay_loading = false;
                    } else {
                        console.log('Request Not Found!');
                    }
                }).catch(err => {
                    console.log('/moldflow_udb_request/api/detail_request err');
                })

                // let request = {
                //      id: '001',
                //     date: '2022/2/14',
                //     email: 'johnson.smith@basf.com',
                //     udbs: [
                //         { id: "001", type: "Ultramid_A3WG7_fiberparam_mf2019.21000" },
                //         { id: "002", type: "Ultramid_Advanced_N3HG6.21000" },
                //     ],
                //     files: [
                //         { name: "contract_a.pdf", url: 'aljfalfadfa'},
                //         { name: "contract_b.pdf", url: 'aljfalfadc'}
                //     ],
                //     status: 0
                // };
                // this.request = request;
            },
            handleRequest(status) {
                if (!this.request.lock) {
                    this.turnOnLoader();
                    let formData = new FormData();
                    formData.append('id', this.id);
                    formData.append('status', status);
                    if (status === 'denied') {
                        formData.append('RejectComment', this.rejectComment);
                    }
                    for (let file of this.upload_missing_udbs) {
                        formData.append('files', file, file.name);
                    }
                    this.$axios.post('/moldflow_udb_request/api/update_request_status', formData).then(res => {
                        console.log(res);
                        if (res.data.message === 'success') {
                            this.turnOffLoader()
                            this.updateHightlightId(res.data.highlight_id);
                            this.$router.push({
                                name: 'pendingRequest'
                            });
                        } else if (res.data.message === 'locked') {
                            this.turnOffLoader();
                            this.request.lock = true;
                            this.turnOnWarningAlert();
                            setTimeout(() => {
                                this.$router.go(0);
                            }, 5000)
                        } else {
                            this.turnOffLoader();
                            this.turnOnErrorAlert();
                        }
                    }).catch(err => {
                        this.turnOffLoader();
                        this.turnOnErrorAlert();
                    })
                }
            },
            approveRequest() {
                this.handleRequest('approved');
            },
            rejectRequest() {
                this.handleRequest('denied');
            }
        }
    }
</script>

<style scoped>
    .row-label {
        text-align: right;
    } 

    .row-label-center {
        text-align: center;
    }

    .missing_udb_upload {
        max-width: 250px;
    }

    .row-label-upload {
        padding-bottom: 0;
    }
</style>