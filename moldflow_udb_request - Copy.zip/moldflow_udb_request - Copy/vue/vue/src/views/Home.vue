<template>
  <div class="home">
    <!--<img src="../assets/logo.png">-->
    <HelloWorld msg="Welcome to Your Vue.js App"/>
    <p class="api-demo">API says:
      <span class="api-output">{{apiResponse}}</span>
    </p>
  </div>
</template>

<script>
// @ is an alias to /src
import HelloWorld from '@/components/HelloWorld.vue'

import axios from 'axios'

export default {
  name: 'home',
  components: {
    HelloWorld
  },
  data () {
    return {
      apiResponse: 'nothing - please wait'
    }
  },
  mounted () {
    // in development, this request will get proxied
    // see vue.config.js for details
    axios.get('api/greeting')
      .then((r) => {
        this.apiResponse = r.data.output
      })
      .catch((e) => {
        this.apiResponse = e
      })
  }
}
</script>

<style lang="stylus" scoped>
.api-demo
  margin 10px 0
  font-size 130%

.api-output
  font-weight bold
</style>