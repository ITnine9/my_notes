<template>
  <v-container class="px-16 compacted">
    <v-card elevation="2" class="mx-auto py-8 text-center">
      <v-form ref="form" v-model="valid" lazy-validation class="px-7">
        <v-text-field label="Search udb" prepend-icon="mdi-magnify" @keyup="fuzzySearch" v-model="searchText"
          :loading="search_bar_toggle" :disabled="search_bar_toggle || missedUdb.length > 0">
          <template v-slot:progress>
            <v-progress-linear color="blue lighten-3" absolute height="2" indeterminate></v-progress-linear>
          </template>
        </v-text-field>

        <SearchResultList :results="searchResult" @addUdb="addItem"></SearchResultList>

        <!-- <v-select
            :items="materials"
            label="Please select a udb"
            v-model="itemSelected"
            item-text="type"
            item-value="id"
            return-object
            @change="selectItem"
          ></v-select> -->

        <selectedList :list="selectedItems" :validate="validate" @delItem="removeSelectedItem"></selectedList>

        
        <!-- <p id="udb_miss_text" 
          class="caption text-right pt-1" 
          @click="missedUbdDialogDisplay = true">
          Could not find the udb?</p> -->
        <v-dialog
          v-model="missedUbdDialogDisplay"
          persistent
          max-width="500"
        >
          <template v-slot:activator="{ on, attrs }">
            <p id="udb_miss_text" 
            class="caption text-right pt-1" 
            v-bind="attrs"
            v-on="on"
            >
            Could not find the udb?</p>
          </template>
          <v-card>
            <v-card-title>
              <span class="text-h5">Add missing udb</span>
            </v-card-title>
            <v-card-text>
              <p>Please input the missing udb, we will add it if we find it in another source. Otherwise, please be patient that we will generate the udb in the future after the testing process.</p>
              <v-text-field v-model="missedUdb" prepend-icon="mdi-file-outline" label="Udb grade name"
                placeholder="example: Ultramid B3WG6 PA6" required class="mt-7"></v-text-field>
            </v-card-text>
            <v-card-actions>
              <v-btn
                color="blue darken-1"
                text
                @click="closeMissingUdbDialog"
              >
                Close
              </v-btn>
              <v-btn
                color="blue darken-1"
                text
                @click="saveMissingUdbDialog"
              >
                Save
              </v-btn>
            </v-card-actions>
          </v-card>
        </v-dialog>
        <v-text-field v-model="missedUdb" v-if="selectedItems.length == 0 && missedUbdInputgDisplay" prepend-icon="mdi-file-outline" label="Missing Udb grade name"
                placeholder="example: Ultramid B3WG6 PA6" required class="mt-7" ></v-text-field>

        <v-text-field v-model="email" :rules="emailRules" prepend-icon="mdi-email-outline" label="Client E-mail"
          placeholder="client_name@xxx.com" required class="mt-7"></v-text-field>

        <div class="mt-7" @dragover.prevent>
          <v-file-input show-size counter multiple label="File input" v-model="files" :rules="fileUploadRules"
            chips @change="onFileChange"></v-file-input>
        </div>

        <div class="text-left mt-1 req_wrapper">
          <p>Please use the following template and upload (请使用以下模板并上传)</p>
          <a
            href="/moldflow_udb_request/api/udb_file_requisition/UDB_file_requisition_list_Chn.docx">UDB_file_requisition_list_Chn.docx</a>,
          <a
            href="/moldflow_udb_request/api/udb_file_requisition/UDB_file_requisition_list_En.docx">UDB_file_requisition_list_En.docx</a>
        </div>
        <!-- preview uploaded files -->
        <v-list>
          <!-- <v-list-item-group
              v-model="selectedItem"
              color="primary"
            > -->
          <v-subheader v-if="preHeaderToggle">Upload file Preview</v-subheader>
          <v-list-item v-for="pdf in prePdfs" :key="pdf.name">
            <v-list-item-content>
              <v-list-item-title><a :href="pdf.url" target="_blank">{{
                pdf.name
              }}</a></v-list-item-title>
            </v-list-item-content>
          </v-list-item>

          <v-list-item v-for="img in preImgs" :key="img.name">
            <v-list-item-content>
              <v-list-item-title>{{ img.name }}</v-list-item-title>
              <v-img :src="img.url" max-height="300" max-width="auto" contain></v-img>
            </v-list-item-content>
          </v-list-item>
          <!-- </v-list-item-group> -->
        </v-list>

        <v-btn class="mx-auto mt-8" color="primary" @click="submitRequest"> Submit </v-btn>
      </v-form>
    </v-card>
  </v-container>
</template>
<script>
import selectedList from "../components/selectedList";
import udb_list from "../assets/udb_list.json";
import SearchResultList from "../components/SearchResultList";
import { mapMutations } from 'vuex'

const fuzzysort = require("fuzzysort");

export default {
  name: "NewRequest",

  components: {
    selectedList,
    SearchResultList,
  },

  data: () => ({
    validate: false,
    search_bar_toggle: false,
    missedUbdDialogDisplay: false,
    missedUbdInputgDisplay: false,
    missedUdb: '',
    searchText: "",
    searchResult: [],
    user: "Jeffrey Wu",
    valid: false,
    materials: [
      { id: "001", type: "Silver" },
      { id: "002", type: "Gold" },
      { id: "003", type: "Bronze" },
      { id: "004", type: "Steel" },
    ],
    itemSelected: {},
    selectedItems: [],
    email: "",
    emailRules: [
      (v) => !!v || "Client Email is required",
      (v) => /.+@.+[a-z]$/.test(v) || "E-mail must be valid",
    ],
    fileUploadRules: [
      v => !!v || "Please upload the UDB_file_requisition_list",
      v => (v && v.length > 0) || 'Please upload the UDB_file_requisition_list',
      v => {
        const allowExt = ['pdf', 'png', 'jpg', 'jpeg', 'gif'];
        for (let file of v) {
          const file_ext_valid = allowExt.includes(file.name.split('.').slice(-1)[0]);
          if (!file_ext_valid) {
            return 'Please upload only pdf or image file';
          }
        }
        return true;
      }
    ],
    files: [],
    prePdfs: [],
    preImgs: [],
  }),
  created() {
    this.getMFs();
  },
  mounted() {
    // this.normalizeMaterials();
  },
  methods: {
    ...mapMutations([
      'turnOnLoader',
      'turnOffLoader',
      'updateHightlightId'
    ]),
    saveMissingUdbDialog() {
      this.missedUbdDialogDisplay = false;
      this.missedUbdInputgDisplay = true;
    },
    closeMissingUdbDialog() {
      this.missedUbdDialogDisplay = false;
      this.missedUbdInputgDisplay = false;
    },
    getMFs() {
      this.search_bar_toggle = true;
      this.$axios.get('/moldflow_udb_request/api/mfdata').then(res => {
        // console.log('/moldflow_udb_request/api/mfdata res:', res.data.mfdata.length);
        console.log('/moldflow_udb_request/api/mfdata res:', res.data.mfdata);
        this.materials = res.data.mfdata;
        this.search_bar_toggle = false;
      }).catch(e => {
        console.log('/moldflow_udb_request/api/mfdata error:', e);
      }).finally(() => {

      })
    },
    submitRequest() {

      // let group_name = 'ultramid';
      // this.$axios.get(`/moldflow_udb_request/api/search_udb/${group_name}`).then(res => {
      //   console.log('backend api res: ', res);
      // }).catch(err => {
      //   console.log('backend api err: ', err);
      // })
      let formValidated = this.$refs.form.validate();
      this.validate = true;
      let udbSelected = this.selectedItems.length > 0 || this.missedUdb;
      console.log('The request validated or not: ', formValidated && udbSelected);

      if (formValidated && udbSelected) {
        const formData = new FormData();
        formData.append('client_email', this.email);
        formData.append('udbs', JSON.stringify(this.selectedItems));
        formData.append('missing_udb', this.missedUdb);
        
        formData.append('files', this.files);
        for (let file of this.files) {
          formData.append('files', file, file.name);
        }
        this.turnOnLoader();
        this.$axios.post(`/moldflow_udb_request/api/add_requests`, formData).then(res => {
          console.log('add_request api res: ', res);
          this.turnOffLoader();
          this.updateHightlightId(res.data.highlight_id);
          this.$router.push({ name: 'pendingRequest' });
        }).catch(err => {
          console.log('add_request api err: ', err);
        })
      }
    },
    addItem(value) {
      if (this.selectedItems.includes(value)) return;
      this.selectedItems.push(value);
    },
    fuzzySearch() {
      let highlighted_result = [];

      this.searchResult = fuzzysort.go(this.searchText, this.materials, {
        key: "name",
        limit: 10,
        allowTypo: false,
        threshold: -100,
      });

      // fuzzysort.highlight(this.searchResult, '<b>', '</b>');
      console.log("Search result: ", this.searchResult);

      const result = fuzzysort.single(
        "query",
        "some string that contains my query."
      );
      // exact match returns a score of 0. lower is worse
      result.score; // -59
      result.indexes; // [29, 30, 31, 32, 33]
      result.target; // some string that contains my query.
      result.obj; // reference to your original obj when using options.key
      console.log(
        "fuzzy highlight: ",
        fuzzysort.highlight(result, "<b>", "</b>")
      );
    },
    // the following method is only for prototyping
    // normalizeMaterials() {
    //   let norlist = udb_list.map((udb, idx) => {
    //     return { id: idx, type: udb };
    //   });
    //   // console.log('norlist: ', norlist);
    //   this.materials = norlist;
    // },
    removeSelectedItem(value) {
      this.selectedItems = this.selectedItems.filter(
        (item) => item.id !== value
      );
    },
    createPreview(file, fn) {
      const reader = new FileReader();

      reader.onload = fn;

      reader.readAsDataURL(file);
    },
    onFileChange(files) {
      let pdfs = [],
        imgs = [];

      console.log("Files: ", files, typeof files);
      if (files.length == 0) {
        this.prePdfs = [];
        this.preImgs = [];
        return;
      }

      pdfs = files.filter(pdfFilter);
      imgs = files.filter(imgFilter);

      pdfs.forEach((pdf) => {
        this.prePdfs.push({
          name: pdf.name,
          url: URL.createObjectURL(pdf),
        });
      });

      imgs.forEach((img) => {
        this.createPreview(img, (e) => {
          this.preImgs.push({
            name: img.name,
            url: e.target.result,
          });
        });
      });
      function imgFilter(file) {
        let ext = file.name.split(".")[1];
        let imgTypes = ["jpg", "jepg", "png"];

        if (imgTypes.includes(ext)) return true;

        return false;
      }

      function pdfFilter(file) {
        let ext = file.name.split(".")[1];
        if (ext === "pdf") return true;

        return false;
      }
    },
    addDropFile(e) {
      this.files = Array.from(e.dataTransfer.files);
    },
  },
  computed: {
    preHeaderToggle() {
      return [...this.prePdfs, ...this.preImgs].length > 0;
    },
  },
};
</script>
<style scoped>
@media (min-width: 960px) {
  .compacted {
    padding-left: 200px !important;
    padding-right: 200px !important;
  }
}

.req_wrapper {
  font-size: 0.8rem;
}

#udb_miss_text {
  color: #1976d2;
  cursor: pointer;
  user-select: none;
}
</style>
