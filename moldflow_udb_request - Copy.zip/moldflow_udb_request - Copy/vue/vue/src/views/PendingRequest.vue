<template>
  <div>
    <v-data-table
      :headers="_headers"
      :items="requests"
      :items-per-page="5"
      :item-class="itemRowBackground"
      class="elevation-1 ma-4 mt-3 row-pointer"
      @click:row="showDetail"
      :loading="loading_toggle"
      loading-text="Loading... Please wait"
      link
    >
      <template v-slot:item.submit_date="{ item }">
          {{ format_date(item.submit_date) }}
      </template>

      <template v-slot:item.udbs="{ item }">
        <v-list-item class="px-0" v-for="udb in item.udbs" :key="udb.id">
          <v-list-item-content>
            <v-list-item-title class="text-body-2">{{ udb.name }}
              <v-icon class="mdi mdi-file-question" v-if="udb.missing"></v-icon>
            </v-list-item-title>
          </v-list-item-content>
        </v-list-item>
      </template>


      <template v-slot:item.files="{ item }">
        <v-list-item class="px-0" v-for="file in item.files" :key="file">
          <v-list-item-content>
            <v-list-item-title class="text-body-2">
                <v-tooltip bottom>
                  <template v-slot:activator="{ on, attrs }">
                    <span v-bind="attrs" v-on="on">{{ format_file(file) }}</span>
                  </template>
                  <span>{{ file }}</span>
                </v-tooltip>
            </v-list-item-title>
          </v-list-item-content>
        </v-list-item>
      </template>


      <template v-slot:item.status="{ item }">
        
        <StatusChip :status=" item.status "></StatusChip>
      </template>

      <!-- <template >
        <v-btn-toggle>
          <v-btn>Approve</v-btn>
          <v-btn>Deny</v-btn>
        </v-btn-toggle>
      </template>
     -->
    </v-data-table>

    
  </div>
</template>
<script>
import RequestTable from "../components/RequestTable.vue";
import StatusChip from "../components/StatusChip";
import { mapMutations } from 'vuex';
import utiliyMixin from "../mixins/mixin"


export default {
  name: "PendingRequest",
  components: {
    RequestTable,
    StatusChip
  },
  mixins: [utiliyMixin],
  data() {
    return {
      headers: [
        {
          text: 'Submission Date', 
          value: 'submit_date',
        },
        {
          text: 'Applicant Email', 
          value: 'requester_email',
        },
        {
          text: 'Udbs', 
          value: 'udbs'
        },
        {
          text: 'Client Email', 
          value: 'client_email'
        },
        {
          text: 'Files', 
          value: 'files',
        },
        {
          text: 'Status', 
          value: 'status'
        },
      ],
      requests: [],
      loading_toggle: true
    }
  },
  created() {
    this.getRequests();
  },
  beforeRouteLeave(to, from, next) {
    this.updateHightlightId('');
    next();
  },
  computed: {
    _headers() {
      if (this.$store.state.user.role != 'admin') {
        return this.headers.filter(h => h.text != 'Applicant Email');
      } else {
        return this.headers;
      }
    }
  },
  methods: {
    format_file(file_name) {
      const max_len = 40;
      if (file_name.length > max_len) {
        return file_name.slice(0, 40) + '...';
      }
      return file_name;
    },
     ...mapMutations([
      'updateHightlightId',
    ]),
    itemRowBackground(item) {
      if (item.u_id === this.$store.state.highlight_id) {
        return 'highlight-table-row-bg'
      }
    },
    format_date(str) {
      return new Date(str).toLocaleString();
    },
    getRequests() {
      this.$axios.get('/moldflow_udb_request/api/requests')
      .then(res => {
        // console.log('/api/requests res: ', res);
        if (res.data.message === 'ok') {
          this.requests = res.data.requests.sort((a, b) => {
            return new Date(b.submit_date) - new Date(a.submit_date);
          })

          this.requests.map(this.addMissingUdb);

          this.loading_toggle = false;
          console.log('this.requests ', this.requests);
        }
      })
      .catch(err => {
        console.log('/api/requests return an error.');
      })
    },
    showDetail(value) {
      console.log('value: ', value);
      this.$router.push({ name: 'detailRequest', params: { id: value.u_id }});
    }
  },
  mounted() {
    
  }

};
</script>
<style>
  .row-pointer > .v-data-table__wrapper > table > tbody > tr:hover {
    cursor: pointer;
  }

  .highlight-table-row-bg {
    background: lightyellow;
  }
</style>