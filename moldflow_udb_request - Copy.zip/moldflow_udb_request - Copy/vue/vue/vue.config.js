module.exports = {
  baseUrl: process.env.NODE_ENV === 'production' ? '/moldflow_udb_request' : '/',

  devServer: {
    proxy: {
      '/moldflow_udb_request/api': {
        target: 'http://127.0.0.1:5000/',
        changeOrigin: true,
        ws: true,
        pathRewrite: {
          '^/moldflow_udb_request/api' : ''
        },
        logLevel: 'debug'
      }
    }
  },

  transpileDependencies: [
    'vuetify'
  ]
}
