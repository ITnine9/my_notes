# Open source software
1. Download compressed file from [gnu.org](https://gnu.org)
2. `$ tar -xJf coreutils-8.28.tar.xz` to decompress the file. Note: - options will change depends on the compression algorithm. (e.g., -J is for xz compression format.)
3. You need gcc to complie the source code written in c.  
   `$ sudo apt install gcc`
4. execute the configure script   
   `$ bash configure`  
   The configue script is to configure the gcc to complie the code according to the computer architecture and create a make file responsible for the new installation of the packages.
5. install the _make_ package  
   `$ sudo apt install make`
6. run make command to complie c code to the machine readable code.
   `$ make`
7. install complied code
   `$ sudo make install`

Note: make is an intellengent program which knows which program you have been modified. 