# Task Automation and Scheduling
## Create a bash script
Bash scripts allow you to automate your workflow.

Put she-bang(#!) at top to let linux know this is a bash script instead of a normal txt file. Following by the path to the bash interpreter in the first line.  
`$ #!/bin/bash`

When you do the following:  
`$ file my_script.sh`  
Now it will show you it's the bash script.

``` 
#!/bin/bash

mkdir ~/script/magic
cd ~/script/magic
touch file{1..100}
ls -l ~/script/magic > ~/script/magic_content.txt
```

## Backup files using script

```
#!/bin/bash

tar -cvzf ~/backup2.tar.gz ~/{Documents,Downloads}
```

Or you could backup only the files inside the Documents directory.
```
#!/bin/bash

cd ~/Documents
tar -cvzf ~/backup2.tar.gz *
```

`/dev/null` is the bitbucket in linux where you could send things you don't want.

## add your script in the bin
You could move your .sh file to ~/bin and remove the .sh extension. 
`$ mv script/backup.sh bin/backup`

`$ chmod +x backup`  
Make the script executable.

Add `~/bin` to **PATH** by editing `the ~/.bashrc` file  
`PATH=$PATH:/home/wuz35/bin`

Therefore, you can run the script no matter where you are in the directory.