# locate and find commands
## _locate_ command
You can use locate command to search for files by name and find them whatever they are.

Note: Depending on what distribution you are running the locate command may not come pre-installed.(e.g., Ubuntu 20.04). You may have to install it from the respository.

There is a **database** stores all the locations of files which locate command will search based on.

`$ locate *.conf`  
Find all .conf files in the system. If you are in specific folder it will search underneath it.

`$ locate -i --limit 3 *.conf`  
Limit the number of search results to 3 and apply the case-insensitive option.

`$ locate -S`  
-S is to show the databse information.  
This db is updated only once a day by default. It means that any changes happen in the meantime will not be logged into the db.

`$ locate -e *.conf`  
Will check if the .conf files exist or not.

`$ locate --follow *.conf`
To make sure symbolic link actually do point to somewhere.

## Updat the database
### _updatedb_ command
You need super user **privilege** to run the command.
`$ sudo updatedb`  
Note: It will take a while to update.

Using the db is very fast, but requires updating.

---

## _find_ command
It allows you to perform sophisticated search tasks.

The _find_ command by default list every single folder and every single file under the current working directory to the infinite depth.   
`$ find`

Other than locate command, the find command search not only files but also folders. It doesn't use database and relatively slower than the formder.

`$ find ~/Downloads/`  
Find files and folders under the Downloads folder.

### contorl search depth

`$ find . -maxdepth 1`  
Showing only folders and files under the current working directory.  
Note: only **one** dash "-" for the maxdepth option.

### Specify the search file type
`$ find . -type f`  
Only search for "file" type.

`$ find -type d`
Only search for "directory" type.

`$ find . -maxdepth 2 -type d`

### Search files by name
`$ find . -name "file5.txt"`
`$ find . -name "*.txt"`  
Wildcards also works here.

`$ find . -maxdepth 1 -name "*.txt"`
maxdepth option can be specified as well.

`$ find . -iname "findme.txt"`  
"i" option is to search the name in **case-insensitive** way.

### search by file size
`$ find . -type f -size +100k`  
Search for files which size is more than 100 kilobytes.

`$ sudo find / -type f -size +1000k`
Adding sudo allows find command to search the folder which needs sudo privilege.

`$ find . -type f -size +1000k | wc -l`
Pipeline to wc (word count) command to count the number of files.

`$ find . -type f -size +1000k -size -5M | wc -l`  
Search for size which is more than 1000 kb **and** less than 5 mb file.  
Note: And above chain option using **and** logic.

`$ find . -type f -size -1000k -o -size +5M | wc -l`  
By putting "-o" option in between two other options to apply "or" logic.

### excute command on each the found result
`$ find . -type f -size +1M -exec cp {} ~/copy_me \;`  
By using "exec" command to execute the following command. "{}" represents every file found.  
Note: You have to use "\;" to specify the end of the command.

`$ find . -type f -size +1M -ok cp {} ~/copy_me \;`  
Instead of using "exec" option you could use "ok" option to make shell interactively to execute the code.

`$ touch folder$(shuf -i 1-500 -n 1)/needle.txt`  
Create a "needle" file in random folder amoung 500. 
In order to find needle in the haystack, use the following command.  
`$ find haystack/ -type f -name "needle.txt"`







