# manipulate file contents
## view file content
### **Cat** command
`$ cat file1.txt`

`$ cat file1.txt file2.txt`  
`$ cat file{1..2}.txt`  
`$ cat file[1-2].txt`  
`$ cat file?.txt`  
Concatenate multiple files (even the mp3 files) at the same time. Wildcards and brace expansion also work here.

`$ cat file?.txt > greet.txt`
Concatenate multiple files contents into one file.

### **tac** command
Reverse the file line-wise (vertically).  
`$ cat file[1-3].txt | tac > reversed.txt`

### **rev** command
Horizontally revese the text in files.
`$ cat file[1-3].txt | rev`

### **less** command
Page through large amount of output.
`$ cat /usr/share/drirc.d/00-mesa-defaults.conf | less`

### **head** and **tail** command
Allow you to see only a part of the file's content.
`$ head /usr/share/drirc.d/00-mesa-defaults.conf`
`$ less /usr/share/drirc.d/00-mesa-defaults.conf`

**head** command by default shows only starting 10 lines of the content.

`$ head greet.txt -n 2`
By specifying the "-n" option, you can display the line at the number you want.

`$ find | head -5 | tac` 
Again, this command is very suitable for the pipeline.

`$ head -n 20 /usr/share/drirc.d/00-mesa-defaults.conf`

**_tail_** command do the exactly the opposite than the **head** command. It starts at the bottom of the file.  
`$ cat greet.txt | tail -n 2`  
`$ tail -n 20 /usr/share/drirc.d/00-mesa-defaults.conf`

These two commands just work like filters to the pipeline.

--- 

## Sorting Date
### **sort** command
It allows you to sort data and make it easier to process in pipelines. This command tends to sort "smallest first"(a-z, 0-9)

`$ sort words.txt`   
`$ sort -r words.txt | less`  
Sort words alphabetical by default, and vice versa.

sort numbers numerically (ascendingly).
`$ sort -n numbers.txt | less`

`$ sort -nr numbers.txt | less`
Sort numbers decendingly

`$ sort -nu numbers0-9.txt | less`
"-u" stands for unique.

### sorting tabular data by columns
`$ ls -l /etc | head -n 20 | sort -k 5n`
By using "-k" option to specify the column you want to sort.

`$ ls -lh /etc | head -n 20 | sort -k 5hr`  
Sorting data column by human-readable file-size format.   
Note: using "h" instead of "n" in this case.

`$ ls -lh /etc | head -n 20 | sort -k 6M`
Sorting column by month.

---

## Searching File Content
### **grep** command
It allows you to search through files and standard outputs. **grep** command return lines that contain a piece of text (wildcards work too).

`$ grep e hello.txt`  
Find every line which contains the letter "e" in hello.txt file. It is case-sensitive by default.

`$ grep -c e hello.txt`
-c option count the lines found.

`$ grep -i gadsby gadsby_manuscript.txt`
-i option is for search in case-insensitive manner.

`$ grep -i "our boys" gadsby_manuscript.txt`
Using quotes to search for the whole phrase.

`$ grep -cv e gadsby_manuscript.txt`
Invert the sense of matching. 

`$ grep -c e hello.txt gadsby_manuscript.txt`
Search through multiple files.

`$ ls -lF / | grep root`
grep command is very useful in pipelines. It filters the large stdout.

`$ ls -F /etc/ | grep -v /`  
-v option is search for the exception.
List all files that are no directory.

`$ man -k print | grep file`

