## Configuration
### Terms
1. Context
2. Directive