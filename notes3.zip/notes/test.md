# Learning **Linux**

### command structure
commandName options inputs