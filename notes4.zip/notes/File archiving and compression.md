# Archive and Compress Files in Linux
Tarballs are containers to store files in for compression. Tarballs can be compressed using various algorithms (e.g., gzip, bzip2, xz).
1. make tarball
2. compress tarball

## **tar** command

`$ tar -cvf ourarchieve.tar file[1-3].txt`
-c option indicate that it is to create an archieve.

-v means verbose

-f is for archiving files.

`$ tar -tf ourarchieve.tar`
Check what is inside the archive without extracting it.  
-t means test label.
-f is necessary to pass file to **tar** command.


`$ tar -xvf ourarchieve.tar`
Extract files from tarball by using -x option. 

## Compressing archive
There are two main compression algorithms in use in Linux world:
1. gzip
2. bzip2

gzip is faster but has less compression power. On the other hand, bzip2 could compress file into smaller archive, but does consume more computational time than the former.

### gzip 
#### Compress the archive
`$ gzip ourarchieve.tar`  
ourarchieve.tar => ourarchieve.tar.gz

#### unzip the compressed tarball
`$ gunzip ourarchieve.tar.gz`
ourarchieve.tar.gz => ourarchieve.tar

### bzip2
#### Compress the archive
`$ bzip2 ourarchieve.tar`
ourarchieve.tar => ourarchieve.tar.bz2
Note: bzip2 is better for the real large file comparing to gzip.

#### undo the compression
`$ bunzip2 ourarchieve.tar.bz2`

### create a zip file for other operating system
`$ zip ourthing.zip file[1-3].txt`

`$ unzip ourthing.zip` 

# create a tarball and compess it at the same time using tar command 
`$ tar -cvzf ourarchive.tar.gz file[1-3].txt`  
-z is for using gzip.

`$ tar -cvjf ourarchive.tar.bz2 file[1-3].txt`
-j is for using bzip2.

`$ tar -xvzf ourarchive.tar.gz`
Extracting gzip compressed tarball by adding -z option.

`$ tar -xvjf ourarchive.tar.bz2`
Extracting bzip2 compressed tarball by adding -j option.

`$ tar -xzvf backup2.tar.gz -C b2`  
Extracting files to a different directory.



