# File Ownership
Every file and directory in Linux is assigned 3 types of owner:
1. User
2. Group
3. Other


# File Permission
Every file and directory has following 3 permissions defined for all the 3 owners mentioned above.
* Read  
  The read permission allows you to open and read a file content. Read permission on a directory gives you the ability to list its content.
* Write 
  It gives you the authority to modify the cotent of a file. For directory, you could add, remove and rename the files in it. 
* Execute
  You cannot execute a file unless the execute permission is set.

# **chmod** command
It stands for 'change mode'. Using the command, we can set permissions (read, write, execute) on a file/directory for the owner, group and the world.

There are two ways to use the command
1. absolute(Numeric) mode
2. symbolic mode

## Numeric Mode
Read 4
Write 2
Execute 1

`$ chmod 764 permission`
Change the permission file, so that the owner has *read*, *write* and *execute* permissions, the group has *read* and *write* permission, the world only has *read* permission.

## Symbolic Mode
In symbolic mode, you can modify permissions of a specific owner. It uses methematical symbols.
"+" Adds a permission to a file/directory
"-" Removes a permission
"=" Overrides the permissions set earlier

The various owners are represents as -
"u" user/owner
"g" group
"o" other
"a" all

`$ chmod o=rwx sample`
`$ chmod g+x sample`
`$ chmod u+r sample`

# Changing Ownership and Group
`$ chown wuz35 sample`

`$ sudo chown root:root sample`
Change both owner and group of a file.

# Changing the group only
`$ sudo chgrp root sample`

`$ cat /etc/group`  
This file contains all the groups defined in the system.

`$ groups`  
List all groups the current user belongs to.

`$ newgrp cdrom`
Change the group currently you are a member of. (e.g., cdrom group)