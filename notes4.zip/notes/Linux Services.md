# Services running under systemd
A service is a process or a group of processes (commonly known as daemons) running continuously in the background, waiting for requests to come in (especially from clients).

Linux supports different ways to manage (start, stop, restart, enable auto-start at system boot, etc.) services, typically through a process or service manager (***systemd***). 

**Systemd** is a system and service manager for Linux; a drop-in replacement for the init process and the **systemctl** command is the primary tool to manage systemd. 

## Init Daemon
The init daemon is the first process executed by the Linux Kernel and its process ID (PID) is always 1. Its purpose is to initialize, manage and track system services and daemons. In other words, the init daemon is the parent of all processes on the system.

