# Open source software
## Compelling software from source code
1. Download compressed file from [gnu.org](https://gnu.org)
2. `$ tar -xJf coreutils-8.28.tar.xz` to decompress the file. Note: - options will change depends on the compression algorithm. (e.g., -J is for xz compression format.)
3. You need gcc to complie the source code written in c.  
   `$ sudo apt install gcc`
4. execute the configure script   
   `$ bash configure`  
   The configue script is to configure the gcc to complie the code according to the computer architecture and create a make file responsible for the new installation of the packages.
5. install the _make_ package  
   `$ sudo apt install make`
6. run make command to complie c code to the machine readable code.
   `$ make`
7. install complied code
   `$ sudo make install`

Note: make is an intellengent program which knows which program you have been modified. 

## The Software Repositories
Big libraries filled with software.  
https://help.ubuntu.com/community/Repositories/Ubuntu
https://packages.ubuntu.com

`$ lsb_release -a` 
The above prints out all information about your ubuntu distribution. For instance, code name.

`$ uname -m`
Display architecture of the system.

## Package managers
Packages are pre-compiled. Thus, no need to complie the souce code before installation.
Manage all these dependency package relatinships.
**apt** stands for advanced package tool. It can also be used to search for packages and download them. It uses caching to speed up performance. 

For morden days, just use **apt** command instead of apt-get and apt-cache
![apt vs apt-get](image/apt_vs_apt-get.png)
`$ apt search <search term>`  
`$ apt show <package-name>`

`$ apt-cache search docx`
Search for packages related to docx.

`$ apt-cache show docx2txt`
Display more information about a certain package.

`$ apt-cache search "web server" | less`
It can be done without internet connection. Use quotes to wrap around the search term.

The cache is stored in at `/var/lib/apt/lists`
`$ cd /var/lib/apt/lists`  
`$ ls | less -N`
-N is to show line number.

`$ /package: gcc\c` 
Search for the gcc package using vim text editor. 
Note: "\c" is meant for search in case-insenstive manner.

All functionalist are performed using the list in the cache.

### update the cache
`$ sudo apt update` 
Performing this task to make sure the local cache package list are the latest/same as the one in the server.

To update every piece of software you installed from repository to the latest version and also upate accordings dependencies, try the following:
`$ sudo apt upgrade`

Note: Make sure you upgrade your packages after update the cache list.

### Installing new packages
You could search for the pacage you want by utilizing the above commands in previous section, then you can decide which package to install.  
`$ sudo apt install x11-apps`  

List all installed packaged.
`$ apt list --installed`

### Downloading the source code
#### Change the sources
The sources list file is located at `/etc/apt/sources.list`.  
`$ sudo vim /etc/apt/sources.list`

Uncomment source links for the source code. (These are commented out by default).
`$ sudo apt update`  
To update the apt cache.

You have to download the **dpkg-dev** package before downloading the soure code. It provides development tool required to unpack, build and upload Debian source packages.

To get the source code of the package.
`$ apt source x11-apps` 

### Uninstalling packages
`$ apt reomve <package name>`  
However, the above command will only remove the package but not the corresponding configuration files. Hence, it is not the perfect way to remove the package.

`$ sudo apt purge <package name>`
Always use **purge** to remove the package completely. 

Remove dependencies that are not needed for any other packages.
`$ sudo apt autoremove`

Delete package archives. Those are located at `/var/cache/apt/archives/`  
`$ sudo apt clean`

Delete packages **except** the one is not longer available in the repository.
`$ sudo apt autoclean`
