# The Linux File System
Pretty much everything in the system can be treated as a file.

## File System
[File System cheat sheet](/cheat%20sheets/File%2BSystem%2BCheat%2BSheet.pdf)

---

## Navigating

`ls -F` 

The 'F' option is to classify the files. (e.g., folders have '/' at the end and file will have extension indicator.)

`ls -l` 
The 'l' option is also very useful.

`ls -h`
For human readable


### cd
Change directory

1. abosulate path
2. relative path
   

### tab auto completion

double tap tab to display multiple possible choices.

## File Extension
`$ file [file]`
Using above command to show file type in the terminal.

Linux does not care the file extension. It reads file type from the header. However, some application (third party software) will assume the file type by the extension name.

Therefore, you could give your file .orig as the original file. And, .copy for backup file. It will not affect the way system works. 

You could even name your file extension whatever you want. (e.g., shablam)

## Wildcards
### *
"*" asterisk matches every piece of text and number.
`$ ls D*`

The above command lists all files starts with the capital letter _D_.

`$ ls *.txt`

### ?
"?" only matches one character.

### []
"[]" the 
`$ ls file[0-9].txt`

## Creating Files and Folders
### _touch_ command

"touch" command is to create files

`$ touch file.txt`  
`$ touch ~/Documents/distantfile.txt`

Both lines of command works.

You could also create a file with initial content with "echo" command.  
`$ echo "hello" > hello.txt`  
">" Redirection will create a new file if the file doesn't exist at first.

### _mkdir_ command

It stands for make directory as the name implies. 

`$ mkdir holiday`  
`$ mkdir ~/Pictures/holiday`  
`$ mkdir "happy birthday"`

"-p" option allows you to create non-existing parent folder.

Note: underscore "_" is better than empty space in the name of file.

#### create multiple folders using _brace expansion_
`$ mkdir {jan,feb,mar,apr,may,jun,jul,aug,sep,oct,nov,dec}_{2020,2021,2022}`  
`$ mkdir {jan,feb,mar,apr,may,jun,jul,aug,sep,oct,nov,dec}_{2020..2022}`  

`$ {a..z} {A..Z} {b..f}`  
Anything with pattern will work using ".."

``
Use ".." shortcut

`$ touch {jan,feb,mar,apr,may,jun,jul,aug,sep,oct,nov,dec}_{2020..2022}/file{1..100}`  
Create 100 files in each folder created before.

`$ touch file{a..c}.txt`
`$ touch file{A,B,C}.txt`  
`$ touch delfolder/deleteme{1..3}/file{1..3}`  
Create multiple files with 

### _rm_ command
Delete files or directorys.

`$ rm file?.*`  
`$ rm *2*`
`$ rm *[2,3]*`
Wildcards make "_rm_" command very powerful.

-i option means interactive. This option is a good compliment with -r option which let you delete multiple things carefully.

### _rmdir_ command
It allows you to only delete empty folders.

`$ rmdir delfolder/*`  
rmdir: failed to remove 'delfolder/deleteme1': Directory not empty  
rmdir: failed to remove 'delfolder/deleteme2': Directory not empty

Note: the "*" wildcard must be used in order for this to work.

## Copy and paste files
### _cp_ command

`$ cp file1.txt file2.txt destination/`  
The last command line argument is the destination where you want to copy files to.

`$ cp destination/* .`  
The wildcards also works for _cp_ command.

`$ cp -r copyme/ destination/`  
The above command copys copyme folder and everyhing inside to the destination.

## Moving and renaming files
### _mv_ command
`$ mv oldname.txt newname.txt`

`$ mv oldfolder/ newfolder`  
Rename the name of folder.

`$ mv moveme/ destination/`  
Moving folder is almost the same as using _cp_ command except applying the -r option.

`$ mv destination/moveme/ ./moveyou`  
Move and rename the folder at the same time.






