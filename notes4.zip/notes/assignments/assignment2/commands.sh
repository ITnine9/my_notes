# Task 1
mkdir super_secret_stuff
touch super_secret_stuff/top_secret.txt
sudo updatedb
locate top_secret > secret_place.txt

# Task 2
# Part A
sudo find / -maxdepth 4 -size +1M -type f
sudo find / -maxdepth 4 -size +1M -type f -exec ls {} -lh \;

# Part B
sudo find / -maxdepth 4 -size +1M -type f -exec ls {} -lh \; 2>&1 | grep -v "Permission denied"| sort -k 5hr > ~/filesizes.txt
