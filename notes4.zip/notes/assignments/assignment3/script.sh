# Task 1

#!/bin/bash

echo "I am hungry. Feed me data." >> ~/demands.txt
date >> ~/demands.log

# Task 2
# crontab
* * * * * bash ~/bin/hungry