# Learning **Linux**

## Terminal Concepts
The terminal contains three part basically
1. shell
2. command
3. terminal 
---
## Command inputs and outputs

command argument is not a standard data stream but accounted as one of the command input

* 0 stands for standard input
* 1 stands for standard output
* 2 stands for standard error output
---
## Data stream redirection

You can use ">" "<" symbols to redirect stdin, stdout or stderr.

`$ cat 0< input.txt 1> hello.txt`  
The above line of code reads the connent in _input.txt_ file as the stdin and then redirect stdout to the file _hello.txt_

Be careful, a single ">" symbom will truncate the file content before writing to it. If you want to append the content to the existing file, use ">>" (double ">") instead.

---
## Piping
Piping is the process to connects stdout of one command to the stdout of another.

`$ date | cut --delimiter " " --fields 1 > today.txt`

Redirection happens before piping, thus it will break the pipeline.

`$ date > date.txt | cut --delimiter " " --fields 1`  
The above commands stops after the redirection. The cut command will not run. The data stream cannot go to two places.

### Tee command
![tee command](image/Tee.svg.png)

`$ date | tee date.txt | cut --delimiter " " --fields 1`

Now, the data will flow to two places.

### xargs command
It allows you to convert the piped data to command line arguments for commands only accecpt command line arguemnts.

`$ date | xargs echo`

`$ date | xargs echo "hello"`

Commands you use with xargs can still have their own arguments.

### Aliases
Be able to create easy-to-remember nicknames for your pipelines.

Create a .bash_aliases file in your home. Then, type the following code.  

`alias getdates='date | tee /home/wuz35/fulldate.txt | cut --delimiter " " --fields 1 | tee /home/wuz35/shortdate.txt | xargs echo hello'`

aliases building block  
`alias calmagic="xargs cal -A 1 -B 1 > /home/wuz35/thing.txt"`

`$ echo "12 2017" | calmagic`

Bonus: aliase will be activated once you restart your terminal

Bonus: make sure the first command can be piped to.





