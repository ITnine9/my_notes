You could refer to [tutorial](https://geekflare.com/nginx-installation-guide-unix/).

1. Download the Nginx source code.
2. Extract the download file.  
   `$ gunzip –c nginx-1.12.2.tar.gz | tar xvf –`
3. Configure  
   `$ ./configure --prefix=/opt/nginx`  
   You might encounter the missing dependencies error. Try to down the rpm package from [rpmfind.net](https://rpmfind.net/) to install.  
   Note: You need both normal package and package ending with "-devel"  
   `$ make`  
   `$ sudo make install`
4. start Nginx  
   cd to sbin/ folder than entering the following commands  
   `$ ./nginx`  
   `$ ./nginx -s stop`

   Using service command  
   `$ sudo service nginx start`
   `$ sudo service nginx stop`
   `$ sudo service nginx restart`