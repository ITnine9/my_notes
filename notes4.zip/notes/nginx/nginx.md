# Nginx Configuration
## Terms
1. Context
2. Directive

## Creating a virtual host
The configuration file is `$ /etc/nginx/nginx.conf`. 

Every virtual host is a **server context(block)** in http block.

`$ nginx -t`
Make sure to verify the configuration file before any modification to take effect.

`$ systemctl reload nginx`
Reboot the nginx, if it failed it will use the previous configuation. This is the preferred way, because it aviods downtime.

`$ systemctl restart nginx`
Reboot the nginx, but if the there is any error it will stop the nginx.

File type is determined by `$ /etc/nginx/mime.types`

## Location block 
This is where we will define and configure the behaviour of specific uris or requests
### match modifiers

The regex match modifier take more precedence than prefix modifiers

1. Exact Match                           =  uri
2. Preferential Match                    ^~ uri
3. REGEX Match (case-insensitive)        ~* uri
4. Prefix Match                             uri

The top one wins over the below.

```
events {

}

http {
    # make nginx to send correct mime types (e.g., for css files)
    include mime.types;

    # virtual host
    server {
        listen 80;
        server_name 127.0.0.1;

        root /sites/demo;

        # prefix match
        location /greet2 {
            return 200 "Greeting from nginx";
        }

        # Preferential prefix match
        # location ^~ /greet2 {
        #     return 200 "Greeting from nginx";
        # }

        # exact match by adding "=" match modifier
        # location = /greet {
        #     return 200 "Greeting from nginx - exact match";
        # }

        # regex match by implementing the pcre library installed with nginx
        # case-sensitive
        # location ~ /greet[0-9] {
        #     return 200 "Greeting from nginx - exact match";
        # }

        # regex match 
        # case-insensitive
        location ~* /greet[0-9] {
            return 200 "Greeting from nginx - exact match - case-insensitive";
        }
    }
}
```

## Variables
There are two types of variable
1. Configuration Variables  
   set $var 'something';
2. Nginx Module Variables [offical doc](http://nginx.org/en/docs/varindex.html)  
   $http, $uri, $args 

The following code will return the server_name of host, the uri of the request and the url arguments.
```
location /inspect {
            return 200 "$host\n$uri\n$args";
        }
```

`$ http://127.0.0.1/inspect?name=jeff`
```
location /inspect {
            return 200 "Name: $arg_name";
        }
```
It could return the specific argument.

**Note**: Using Nginx variable in the location block is highly not recommanded. It will lead to unexpected problems. The above examples are just for demostration purpose.

```
if ($arg_apikey != 1234) {
            return 401 "The api key is incorrect!";
        } 
        
        return 200 "Corrent API key!";
```


This is how you set your own variables.
Custom variable type could be:
1. String
2. Integer
3. Boolean

```
server {
    listen 80;
    server_name 127.0.0.1;

    root /sites/demo;

    set $weekend "No";

    if ( $date_local ~ 'Saturday|Sunday' ) {
        set $weekend "Yes";
    }

    location /is_weekend {
        return 200 "Is it weekend?\n$date_local\n$weekend";
    }

}
```

## Rewrites & Redirects
### Redirection
return **200** "some string"  
return **307** /some/path/

```
server {
    listen 80;
    server_name 127.0.0.1;

    root /sites/demo;

    location /image {
        return 307 /minion_a.jpg;
    }

}
```

http://127.0.0.1/image => http://127.0.0.1/minion_a.jpg

### Rewrite
However, rewrite will change the uri request internally.
The rewrite will make nginx revaluation all location blocks again. It's powerful but costs more resources than *return* operation.
```
server {
    listen 80;
    server_name 127.0.0.1;

    root /sites/demo;

    rewrite ^/user/\w+ /greet;

    # rewrite destination
    location /greet {
        return 200 "Hello user";
    }
}
```
http://127.0.0.1/user/jeff => http://127.0.0.1/user/jeff  
The url will not be changed. This is different from redirection using *return*.

The advantage of rewrite is that it can capture the group of uri.
```
rewrite ^/user/(\w+) /greet/$1;

location = /greet/john {
            return 200 "Hello John";
}
```


By appending the key word **last**, the rewrite operation will skip the rest one. In this case, the second rewrite rule will be ignored.
```
rewrite ^/user/(\w+) /greet/$1 last;
rewrite ^/greet/john /minion_a.jpg;
```

## Try Files
![try_files](image/../../image/try_files.png)
It works both in server context and location block.

```
server {
    listen 80;
    server_name 127.0.0.1;

    root /sites/demo;

    try_files $uri /minion_b.jpg /greet /friendly_404;

    location /friendly_404 {
        return 404 "Page not found!";
    }

    location /greet {
        return 200 "Hello user";
    }
}
```

`try_files path1 path2 ... pathn final_rewrite`
path is relative to the root. The final_rewrite will cause a revaluation.

### Named location
The named location will be prefixed with "@".
```
try_files $uri /minion_b.jpg /greet @friendly_404;

location @friendly_404 {
    return 404 "Page not found!";
}
```

## Logging
1. Error log  
   As the name suggests, it is for anything that faided or didn't happen as expected.
2. Access log  
   It logs all requests to the server.

These logs reside at `/var/log/nginx`

Note: 404 are proper respondes that are in the both access log and error log if you don't handle 404 situation directly.

### Create a customized log
```
location /secure {
    access_log /var/log/nginx/secure.access.log;
    return 200 "Welcome to secure area.";
}
```

```
access_log /var/log/nginx/secure.access.log;
access_log /var/log/nginx/access.log;
```
The access record will now appear in both access logs.

## Inheritance & Directive types
![inheritance](image/../../image/inheritance.png)

Three directive types:
1. Standard Directive
2. Array Directive
3. Action Directive

For detailed explaination, refer to [doc](./07%2BInheritince%2B%26%2BDirective%2BTypes.conf).